# Restaurant website (Node)

Public site + password-protected editor at `/admin/` (sign in with any username and the
admin password). Edits are saved to `data/content.json` and show on the site straight away.

Hosted layout (managed by the dashboard):
- `server.js`, `public/` - the app (mounted read-only in the container)
- `data/content.json` - all editable content (kept in backups)
- `data/.admin_password` - salted hash of the admin password (never the password itself)

To change the admin password, run on the host (replace SITE; it prompts, nothing is echoed):

    sudo python3 -c "import hashlib,os,getpass;D=chr(36);p=getpass.getpass().encode();s=os.urandom(16);f='/opt/wp-host/sites/SITE/site/data/.admin_password';os.path.exists(f) and os.chmod(f,0o600);open(f,'w').write(D.join(['scrypt','16384','8','1',s.hex(),hashlib.scrypt(p,salt=s,n=16384,r=8,p=1,dklen=32).hex()]));os.chmod(f,0o400);os.chown(f,33,33)"

No restart is needed. Run `node server.js` locally with `ADMIN_PASSWORD=...` to preview.
