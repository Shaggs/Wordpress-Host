'use strict';

// Crazy Indian website server.
// - Serves the public site from /public
// - Serves the content API at /api/content (public, read-only)
// - Serves the admin panel at /admin (HTTP Basic auth, password from ADMIN_PASSWORD)
// - Saves edits to a JSON file (DATA_FILE). No database or npm packages needed.

const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const PORT = Number(process.env.PORT) || 3000;
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || '';
// Hosted setups keep the password in a file (ADMIN_PASSWORD_FILE) so it never sits in an
// environment variable. The file holds either the plain password or a hash written by the
// platform:  scrypt$N$r$p$saltHex$hashHex   It is re-read when it changes, so a password
// change takes effect without a restart.
const ADMIN_PASSWORD_FILE = process.env.ADMIN_PASSWORD_FILE || '';
const PUBLIC_DIR = path.join(__dirname, 'public');
const SEED_FILE = path.join(__dirname, 'data', 'content.json');
const DATA_FILE = process.env.DATA_FILE || SEED_FILE;
const MAX_BODY = 1024 * 1024; // 1 MB

const COLOUR_KEYS = ['bg', 'surface', 'line', 'text', 'muted', 'accent', 'accent2', 'accent3'];
const FONTS = ['Anton', 'Bebas Neue', 'Oswald'];
const HEX = /^#[0-9a-fA-F]{6}$/;

const HASH_RE = /^scrypt\$(\d+)\$(\d+)\$(\d+)\$([0-9a-f]+)\$([0-9a-f]+)$/;
const authCache = new Map(); // sha256(Authorization header) -> expiry, successful sign-ins only
let secretCache = { mtime: -1, value: '' };
function adminSecret() {
  if (!ADMIN_PASSWORD_FILE) return ADMIN_PASSWORD;
  try {
    const st = fs.statSync(ADMIN_PASSWORD_FILE);
    if (st.mtimeMs !== secretCache.mtime) {
      secretCache = { mtime: st.mtimeMs, value: fs.readFileSync(ADMIN_PASSWORD_FILE, 'utf8').replace(/[\r\n]+$/, '') };
      authCache.clear();
    }
    return secretCache.value;
  } catch {
    return '';
  }
}

const initialSecret = adminSecret();
if (!HASH_RE.test(initialSecret) && initialSecret.length < 8) {
  console.error('Set ADMIN_PASSWORD or ADMIN_PASSWORD_FILE (at least 8 characters) before starting the server.');
  process.exit(1);
}

// First run on a fresh disk: copy the shipped content into the data file.
if (path.resolve(DATA_FILE) !== path.resolve(SEED_FILE) && !fs.existsSync(DATA_FILE)) {
  fs.mkdirSync(path.dirname(DATA_FILE), { recursive: true });
  fs.copyFileSync(SEED_FILE, DATA_FILE);
}

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.webp': 'image/webp',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon',
};

function httpError(status, message) {
  return Object.assign(new Error(message), { status });
}

function send(res, status, body, headers = {}) {
  res.writeHead(status, { 'X-Content-Type-Options': 'nosniff', 'Referrer-Policy': 'same-origin', 'X-Frame-Options': 'SAMEORIGIN', ...headers });
  res.end(body);
}

function sendJson(res, status, obj) {
  send(res, status, JSON.stringify(obj), {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store',
  });
}

function tooMany(res) {
  send(res, 429, 'Too many failed sign-in attempts. Try again in 15 minutes.', {
    'Retry-After': '900',
    'Content-Type': 'text/plain; charset=utf-8',
  });
}

function challenge(res) {
  send(res, 401, 'Sign in required', {
    'WWW-Authenticate': 'Basic realm="Crazy Indian site editor", charset="UTF-8"',
    'Content-Type': 'text/plain; charset=utf-8',
  });
}

function verifyPassword(password, secret) {
  const m = HASH_RE.exec(secret);
  if (!m) {
    // Plain password: hash both sides so the comparison is constant-time and length-independent.
    const a = crypto.createHash('sha256').update(password).digest();
    const b = crypto.createHash('sha256').update(secret).digest();
    return Promise.resolve(crypto.timingSafeEqual(a, b));
  }
  const [, N, r, p, saltHex, hashHex] = m;
  const expected = Buffer.from(hashHex, 'hex');
  return new Promise((resolve) => {
    crypto.scrypt(password, Buffer.from(saltHex, 'hex'), expected.length,
      { N: Number(N), r: Number(r), p: Number(p), maxmem: 128 * 1024 * 1024 }, (err, derived) => {
        resolve(!err && derived.length === expected.length && crypto.timingSafeEqual(derived, expected));
      });
  });
}

// Failed sign-ins are slowed down and limited per visitor. Behind Cloudflare the real visitor
// address is in CF-Connecting-IP; otherwise the proxy's X-Real-IP, then the socket address.
const FAIL_WINDOW_MS = 15 * 60 * 1000;
const FAIL_LIMIT = 10;
const fails = new Map(); // key -> [timestamps]
function clientKey(req) {
  const h = req.headers;
  return String(h['cf-connecting-ip'] || h['x-real-ip'] || req.socket.remoteAddress || 'unknown').slice(0, 64);
}
function recentFails(key) {
  const now = Date.now();
  const list = (fails.get(key) || []).filter((t) => now - t < FAIL_WINDOW_MS);
  if (list.length) fails.set(key, list); else fails.delete(key);
  return list;
}
setInterval(() => { for (const k of [...fails.keys()]) recentFails(k); }, 5 * 60 * 1000).unref();

// Returns 'ok', 'denied' or 'limited'.
async function checkAdmin(req) {
  const key = clientKey(req);
  if (recentFails(key).length >= FAIL_LIMIT) return 'limited';
  const header = req.headers.authorization || '';
  if (!header.startsWith('Basic ')) return 'denied'; // the browser's first, credential-less request
  const secret = adminSecret();
  const cacheKey = crypto.createHash('sha256').update(header).digest('hex');
  const hit = authCache.get(cacheKey);
  if (hit && hit > Date.now()) return 'ok';
  const decoded = Buffer.from(header.slice(6), 'base64').toString('utf8');
  const password = decoded.slice(decoded.indexOf(':') + 1);
  if (secret && await verifyPassword(password, secret)) {
    if (authCache.size > 200) authCache.clear();
    authCache.set(cacheKey, Date.now() + 5 * 60 * 1000);
    return 'ok';
  }
  fails.set(key, [...recentFails(key), Date.now()]);
  await new Promise((r) => setTimeout(r, 1000)); // slow guessing down
  return 'denied';
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let size = 0;
    const chunks = [];
    req.on('data', (chunk) => {
      size += chunk.length;
      if (size > MAX_BODY) {
        reject(httpError(413, 'Content is too large'));
        req.destroy();
        return;
      }
      chunks.push(chunk);
    });
    req.on('end', () => resolve(Buffer.concat(chunks).toString('utf8')));
    req.on('error', reject);
  });
}

// Keep only plain JSON data, cap string lengths and nesting depth.
function deepClean(value, depth = 0) {
  if (depth > 8) return undefined;
  if (typeof value === 'string') return value.slice(0, 1000);
  if (typeof value === 'number' && Number.isFinite(value)) return value;
  if (typeof value === 'boolean' || value === null) return value;
  if (Array.isArray(value)) return value.slice(0, 500).map((v) => deepClean(v, depth + 1));
  if (typeof value === 'object') {
    const out = {};
    for (const key of Object.keys(value).slice(0, 100)) {
      if (key.length <= 50) out[key] = deepClean(value[key], depth + 1);
    }
    return out;
  }
  return undefined;
}

function validate(c) {
  const fail = (msg) => { throw httpError(400, msg); };
  if (!c || typeof c !== 'object' || Array.isArray(c)) fail('Content must be an object');

  for (const key of ['business', 'theme', 'home', 'menu', 'hours', 'delivery', 'contact']) {
    if (!c[key] || typeof c[key] !== 'object') fail(`Missing section: ${key}`);
  }
  for (const key of COLOUR_KEYS) {
    if (!HEX.test(c.theme[key] || '')) fail(`Colour "${key}" must be a hex value such as #120d0a`);
  }
  if (!FONTS.includes(c.theme.displayFont)) fail('Heading font is not one of the supported fonts');
  if (c.business.orderUrl && !/^https?:\/\//.test(c.business.orderUrl)) {
    fail('Online ordering link must start with https://');
  }
  if (!Array.isArray(c.menu.categories) || c.menu.categories.length > 60) fail('Menu categories are invalid');
  for (const cat of c.menu.categories) {
    if (!Array.isArray(cat.items)) fail('Each menu category needs an items list');
  }
  if (!Array.isArray(c.hours.days) || c.hours.days.length !== 7) fail('Hours must list all 7 days');
  if (!Array.isArray(c.delivery.suburbs)) fail('Delivery suburbs must be a list');
  if (!Array.isArray(c.home.picks) || !Array.isArray(c.home.stripe) || !Array.isArray(c.home.aboutParagraphs)) {
    fail('Home page lists are invalid');
  }
  return c;
}

function readContent() {
  return JSON.parse(fs.readFileSync(DATA_FILE, 'utf8'));
}

function writeContent(content) {
  // Keep one previous version as a safety net.
  if (fs.existsSync(DATA_FILE)) fs.copyFileSync(DATA_FILE, DATA_FILE + '.bak');
  const tmp = DATA_FILE + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(content, null, 2) + '\n');
  fs.renameSync(tmp, DATA_FILE);
}

function serveStatic(req, res, pathname) {
  if (req.method !== 'GET' && req.method !== 'HEAD') {
    return send(res, 405, 'Method not allowed', { 'Content-Type': 'text/plain; charset=utf-8' });
  }
  let rel = pathname === '/' ? '/index.html' : pathname;
  if (rel.endsWith('/')) rel += 'index.html';
  const file = path.normalize(path.join(PUBLIC_DIR, rel));
  if (!file.startsWith(PUBLIC_DIR + path.sep)) {
    return send(res, 403, 'Forbidden', { 'Content-Type': 'text/plain; charset=utf-8' });
  }
  fs.stat(file, (err, stat) => {
    if (err || !stat.isFile()) {
      return send(res, 404, 'Not found', { 'Content-Type': 'text/plain; charset=utf-8' });
    }
    res.writeHead(200, {
      'Content-Type': MIME[path.extname(file).toLowerCase()] || 'application/octet-stream',
      'Cache-Control': 'no-cache',
      'X-Content-Type-Options': 'nosniff',
      'X-Frame-Options': 'SAMEORIGIN',
    });
    if (req.method === 'HEAD') return res.end();
    fs.createReadStream(file).pipe(res);
  });
}

const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, 'http://localhost');
    const pathname = decodeURIComponent(url.pathname);

    // Container health check.
    if (pathname === '/healthz') {
      return send(res, 200, 'ok', { 'Content-Type': 'text/plain; charset=utf-8', 'Cache-Control': 'no-store' });
    }

    // Public content for the website.
    if (req.method === 'GET' && pathname === '/api/content') {
      return sendJson(res, 200, readContent());
    }

    // Admin API.
    if (pathname.startsWith('/api/admin/')) {
      const auth = await checkAdmin(req);
      if (auth === 'limited') return tooMany(res);
      if (auth !== 'ok') return challenge(res);
      if (req.method === 'GET' && pathname === '/api/admin/check') {
        return sendJson(res, 200, { ok: true });
      }
      if (req.method === 'PUT' && pathname === '/api/admin/content') {
        const raw = await readBody(req);
        let parsed;
        try {
          parsed = JSON.parse(raw);
        } catch {
          throw httpError(400, 'Invalid JSON');
        }
        const content = validate(deepClean(parsed));
        writeContent(content);
        return sendJson(res, 200, { ok: true, savedAt: new Date().toISOString() });
      }
      return sendJson(res, 404, { error: 'Not found' });
    }

    // Admin pages require sign-in.
    if (pathname === '/admin' || pathname.startsWith('/admin/')) {
      const auth = await checkAdmin(req);
      if (auth === 'limited') return tooMany(res);
      if (auth !== 'ok') return challenge(res);
      if (pathname === '/admin') {
        res.writeHead(301, { Location: '/admin/' });
        return res.end();
      }
    }

    return serveStatic(req, res, pathname);
  } catch (err) {
    const status = err.status || 500;
    if (status === 500) console.error(err);
    sendJson(res, status, { error: status === 500 ? 'Server error' : err.message });
  }
});

server.listen(PORT, () => {
  console.log(`Crazy Indian site running on port ${PORT}`);
  console.log(`Content file: ${DATA_FILE}`);
});
