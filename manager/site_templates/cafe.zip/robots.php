<?php
// Served as /robots.txt (see .htaccess)
$c   = require __DIR__ . '/config.php';
$url = rtrim((string)($c['seo']['site_url'] ?? ''), '/');
header('Content-Type: text/plain; charset=utf-8');
echo "User-agent: *\nAllow: /\nDisallow: /admin/\n";
if ($url !== '') {
    echo "\nSitemap: $url/sitemap.xml\n";
}
