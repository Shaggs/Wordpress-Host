<?php
// The layouts a customer can choose from in the admin dashboard.
// To add another, create layouts/layout-N.php (and assets/css/layout-N.css) and list it here.
return [
    1 => [
        'name'        => 'Classic',
        'description' => 'Centred photo banner, menu in cards, photo grid.',
    ],
    2 => [
        'name'        => 'Split screen',
        'description' => 'Headline beside a large photo, bold menu panel, photo mosaic.',
    ],
    3 => [
        'name'        => 'Menu first',
        'description' => 'Full-screen photo with quick Order, Book and Call buttons, tabbed menu.',
    ],
];
