<?php require __DIR__ . '/_shared.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <?= head_tags($c) ?>
  <link rel="stylesheet" href="assets/css/style.css?v=<?= @filemtime(__DIR__ . '/../assets/css/style.css') ?>">
  <style><?= theme_css($c) ?></style>
</head>
<body>
<?= body_start($c) ?>

<header class="site-header">
  <div class="container nav">
    <?php if ($logoImage): ?>
      <img src="<?= $e($logoImage) ?>" alt="<?= $e($c['name']) ?>" class="logo">
    <?php else: ?>
      <strong class="brand"><?= $e($c['name']) ?></strong>
    <?php endif; ?>
    <nav>
      <a href="#about">About</a>
      <?php if ($menuData): ?><a href="#menu">Menu</a><?php endif; ?>
      <?php if ($orderUrl): ?><a href="#order">Order</a><?php endif; ?>
      <?php if ($bookUrl): ?><a href="#book">Book</a><?php endif; ?>
      <?php if ($galleryData): ?><a href="#gallery">Gallery</a><?php endif; ?>
      <?php if ($hasVisit): ?><a href="#visit">Visit</a><?php endif; ?>
    </nav>
  </div>
</header>

<section class="hero"<?= $heroImage ? ' style="background-image: url(\'' . $e($heroImage) . '\');"' : '' ?>>
  <div class="hero-overlay">
    <h1><?= $e($c['name']) ?></h1>
    <p><?= $e($c['tagline']) ?></p>
    <div class="hero-actions">
      <?php if ($orderUrl): ?><a href="#order" class="btn" data-track="order">Order online</a><?php endif; ?>
      <?php if ($bookUrl): ?><a href="#book" class="btn" data-track="book">Book a table</a><?php endif; ?>
      <?php if ($hasVisit): ?><a href="#visit" class="btn<?= ($orderUrl || $bookUrl) ? ' btn-outline' : '' ?>">Visit us</a><?php endif; ?>
    </div>
  </div>
</section>

<section id="about" class="section container">
  <h2>Our Story</h2>
  <p class="lead"><?= $e($c['about']) ?></p>
</section>

<?php if ($menuData): ?>
<section id="menu" class="section section-alt">
  <div class="container">
    <h2>Menu</h2>
    <div class="menu-grid">
      <?php foreach ($menuData as $category => $items): ?>
        <div class="card">
          <h3><?= $e($category) ?></h3>
          <ul class="menu-list">
            <?php foreach ($items as $row): ?>
              <li>
                <span><?= $e($row['item']) ?></span>
                <span class="price"><?= $e($row['price']) ?></span>
              </li>
            <?php endforeach; ?>
          </ul>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>
<?php endif; ?>

<?php if ($orderUrl): ?>
<section id="order" class="section container">
  <h2>Order Online</h2>
  <?= embed_frame($orderUrl, 'Order online from ' . $c['name']) ?>
  <p class="embed-note">Trouble loading? <a href="<?= $e($orderUrl) ?>" target="_blank" rel="noopener">Open ordering in a new tab</a>.</p>
</section>
<?php endif; ?>

<?php if ($galleryData): ?>
<section id="gallery" class="section container">
  <h2>Gallery</h2>
  <div class="gallery">
    <?php foreach ($galleryData as $img): ?>
      <img src="<?= $e($img) ?>" alt="<?= $e($c['name']) ?> photo" loading="lazy">
    <?php endforeach; ?>
  </div>
</section>
<?php endif; ?>

<?php if ($bookUrl): ?>
<section id="book" class="section section-alt">
  <div class="container">
    <h2>Book a Table</h2>
    <?= embed_frame($bookUrl, 'Book a table at ' . $c['name']) ?>
    <p class="embed-note">Trouble loading? <a href="<?= $e($bookUrl) ?>" target="_blank" rel="noopener">Open booking in a new tab</a>.</p>
  </div>
</section>
<?php endif; ?>

<?php if ($hasVisit): ?>
<section id="visit" class="section<?= $bookUrl ? '' : ' section-alt' ?>">
  <div class="container visit-grid">
<?php if ($hoursData): ?>
    <div class="card">
      <h2>Opening Hours</h2>
      <ul class="menu-list">
        <?php foreach ($hoursData as $day => $time): ?>
          <li><span><?= $e($day) ?></span><span><?= $e($time) ?></span></li>
        <?php endforeach; ?>
      </ul>
    </div>
<?php endif; ?>
<?php if ($hasContact || $hasMap): ?>
    <div class="card">
      <?php if ($hasContact): ?><h2>Find Us</h2><?php endif; ?>
      <?php if ($hasAddress): ?><p><?= $e($ct['address']) ?></p><?php endif; ?>
      <?php if ($hasPhone): ?><p>Phone: <a href="<?= $e($phoneHref) ?>" data-track="call"><?= $e($ct['phone']) ?></a></p><?php endif; ?>
      <?php if ($hasEmail): ?><p>Email: <a href="mailto:<?= $e($ct['email']) ?>"><?= $e($ct['email']) ?></a></p><?php endif; ?>
      <?php if ($hasMap): ?>
        <iframe class="map" src="<?= $e($ct['map_embed']) ?>" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
      <?php endif; ?>
    </div>
<?php endif; ?>
  </div>
</section>
<?php endif; ?>

<footer class="site-footer">
  <div class="container">
    <p>&copy; <?= date('Y') ?> <?= $e($c['name']) ?> &middot; Made &amp; maintained by <a class="tel5-credit" href="https://tel5.com.au" target="_blank" rel="noopener">Tel5</a></p>
    <p class="social">
      <?php foreach ($socialLinks as $label => $url): ?><a href="<?= $e($url) ?>" target="_blank" rel="noopener"><?= $e($label) ?></a>
      <?php endforeach; ?>
      <?= privacy_link($c) ?>
    </p>
  </div>
</footer>

<?= body_end($c) ?>
</body>
</html>
