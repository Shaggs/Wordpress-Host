<?php
// Button styles for ordering/booking links that open the provider in a new tab.
// Used by the website (layouts/_shared.php) and by the editor's style picker.
const EMBED_BUTTON_STYLES = [
    'solid'   => 'Solid',
    'accent'  => 'Accent colour',
    'outline' => 'Outline',
    'square'  => 'Square, capitals',
    'shadow'  => 'Soft card',
    'card'    => 'Large card',
    'link'    => 'Text link',
];
const EMBED_BUTTON_CSS = '.embed-button{text-align:center;padding:2.5rem 1rem}'
    . '.embed-button>p{margin-top:.75rem;font-size:.9rem;opacity:.75}'
    . '.embed-button+.embed-note,.embed-button+.note{display:none}'
    . '.embed-btn{display:inline-flex;align-items:center;justify-content:center;gap:.5rem;text-decoration:none;font-weight:700;font-size:1.1rem;line-height:1.2;transition:transform .15s ease,box-shadow .15s ease;cursor:pointer;border:0;box-shadow:none;white-space:nowrap;max-width:100%}'
    . '.embed-btn:hover{transform:translateY(-2px)}'
    . '.embed-btn.s-solid{background:var(--primary);color:var(--on-primary);padding:1rem 2.25rem;border-radius:999px}'
    . '.embed-btn.s-accent{background:var(--accent);color:var(--on-accent);padding:1rem 2.25rem;border-radius:999px}'
    . '.embed-btn.s-outline{background:transparent;color:var(--primary);border:2px solid var(--primary);padding:.9rem 2.1rem;border-radius:999px}'
    . '.embed-btn.s-outline:hover{background:var(--primary);color:var(--on-primary)}'
    . '.embed-btn.s-square{background:var(--primary);color:var(--on-primary);padding:1.05rem 2.5rem;border-radius:6px;text-transform:uppercase;letter-spacing:.08em;font-size:.95rem}'
    . '.embed-btn.s-shadow{background:var(--surface,#fff);color:var(--text);padding:1rem 2.25rem;border-radius:14px;border:1px solid rgba(0,0,0,.08);box-shadow:0 8px 24px rgba(0,0,0,.14)}'
    . '.embed-btn.s-shadow:hover{box-shadow:0 12px 30px rgba(0,0,0,.2)}'
    . '.embed-btn.s-card{flex-direction:column;align-items:flex-start;gap:.3rem;min-width:min(320px,100%);background:var(--primary);color:var(--on-primary);padding:1.4rem 1.8rem;border-radius:18px;text-align:left;box-shadow:0 10px 30px rgba(0,0,0,.18)}'
    . '.embed-btn.s-card .t{font-size:1.35rem}.embed-btn.s-card .sub{font-size:.85rem;font-weight:500;opacity:.8}'
    . '.embed-btn.s-link{background:none;color:var(--primary);padding:.25rem 0;border-radius:0;font-size:1.3rem;text-decoration:underline;text-underline-offset:5px;text-decoration-thickness:2px}';
