<?php
require __DIR__ . '/_shared.php';
$gallery = $galleryData;
$menu    = $menuData;
$tabbed  = count($menu) > 1;
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <?= head_tags($c) ?>
  <link rel="stylesheet" href="assets/css/layout-3.css?v=<?= @filemtime(__DIR__ . '/../assets/css/layout-3.css') ?>">
  <style><?= theme_css($c) ?></style>
  <script>document.documentElement.classList.add('js');</script>
</head>
<body>
<?= body_start($c) ?>

<section class="hero" style="background-image: linear-gradient(to top, rgba(0,0,0,.78), rgba(0,0,0,.1) 65%)<?= $heroImage ? ", url('" . $e($heroImage) . "')" : '' ?>;">
  <header class="bar">
    <?php if ($logoImage): ?>
      <a href="#" class="brand"><img src="<?= $e($logoImage) ?>" alt="<?= $e($c['name']) ?>"></a>
    <?php else: ?>
      <a href="#" class="brand"><?= $e($c['name']) ?></a>
    <?php endif; ?>
    <nav aria-label="Main">
      <?php if ($menuData): ?><a href="#menu">Menu</a><?php endif; ?>
      <a href="#about">About</a>
      <?php if ($hasVisit): ?><a href="#visit">Visit</a><?php endif; ?>
    </nav>
  </header>
  <div class="hero-text">
    <h1><?= $e($c['name']) ?></h1>
    <p><?= $e($c['tagline']) ?></p>
  </div>
</section>

<?php if ($orderUrl || $bookUrl || $hasPhone): ?>
<nav class="dock" aria-label="Quick actions">
  <?php if ($orderUrl): ?><a href="#order" data-track="order">Order online</a><?php endif; ?>
  <?php if ($bookUrl): ?><a href="#book" data-track="book">Book a table</a><?php endif; ?>
  <?php if ($hasPhone): ?><a href="<?= $e($phoneHref) ?>" data-track="call">Call us</a><?php endif; ?>
</nav>
<?php endif; ?>

<?php if ($menuData): ?>
<section id="menu" class="menu<?= $tabbed ? ' tabbed' : '' ?>">
  <div class="col">
    <h2>Menu</h2>
    <?php if ($tabbed): ?>
      <div class="tabs" role="tablist" aria-label="Menu categories">
        <?php $i = 0; foreach ($menu as $category => $items): ?>
          <button type="button" role="tab" id="tab-<?= $i ?>" aria-controls="panel-<?= $i ?>"
                  aria-selected="<?= $i === 0 ? 'true' : 'false' ?>" tabindex="<?= $i === 0 ? '0' : '-1' ?>"><?= $e($category) ?></button>
        <?php $i++; endforeach; ?>
      </div>
    <?php endif; ?>
    <?php $i = 0; foreach ($menu as $category => $items): ?>
      <div class="panel" id="panel-<?= $i ?>"<?= $tabbed ? ' role="tabpanel" aria-labelledby="tab-' . $i . '"' : '' ?>>
        <h3><?= $e($category) ?></h3>
        <ul>
          <?php foreach ($items as $row): ?>
            <li><span><?= $e($row['item']) ?></span><span class="price"><?= $e($row['price']) ?></span></li>
          <?php endforeach; ?>
        </ul>
      </div>
    <?php $i++; endforeach; ?>
  </div>
</section>
<?php endif; ?>

<section id="about" class="about">
  <div class="col">
    <h2>Our story</h2>
    <p><?= $e($c['about']) ?></p>
  </div>
</section>

<?php if ($gallery): ?>
<section id="gallery" class="strip" tabindex="0" aria-label="Photo gallery, scroll sideways">
  <?php foreach ($gallery as $img): ?>
    <img src="<?= $e($img) ?>" alt="<?= $e($c['name']) ?> photo" loading="lazy" onerror="this.style.opacity=0">
  <?php endforeach; ?>
</section>
<?php endif; ?>

<?php if ($orderUrl): ?>
<section id="order" class="embed">
  <div class="col-wide">
    <h2>Order online</h2>
    <?= embed_frame($orderUrl, 'Order online from ' . $c['name']) ?>
    <p class="note">Trouble loading? <a href="<?= $e($orderUrl) ?>" target="_blank" rel="noopener">Open ordering in a new tab</a>.</p>
  </div>
</section>
<?php endif; ?>

<?php if ($bookUrl): ?>
<section id="book" class="embed<?= $orderUrl ? ' embed-alt' : '' ?>">
  <div class="col-wide">
    <h2>Book a table</h2>
    <?= embed_frame($bookUrl, 'Book a table at ' . $c['name']) ?>
    <p class="note">Trouble loading? <a href="<?= $e($bookUrl) ?>" target="_blank" rel="noopener">Open booking in a new tab</a>.</p>
  </div>
</section>
<?php endif; ?>

<?php if ($hasVisit): ?>
<section id="visit" class="visit">
  <div class="col-wide visit-grid">
<?php if ($hoursData): ?>
    <div>
      <h2>Hours</h2>
      <ul class="hours">
        <?php foreach ($hoursData as $day => $time): ?>
          <li><span><?= $e($day) ?></span><span><?= $e($time) ?></span></li>
        <?php endforeach; ?>
      </ul>
    </div>
<?php endif; ?>
<?php if ($hasContact): ?>
    <div>
      <h2>Find us</h2>
      <address>
        <?php if ($hasAddress): ?><div><?= $e($ct['address']) ?></div><?php endif; ?>
        <?php if ($hasPhone): ?><div><a href="<?= $e($phoneHref) ?>" data-track="call"><?= $e($ct['phone']) ?></a></div><?php endif; ?>
        <?php if ($hasEmail): ?><div><a href="mailto:<?= $e($ct['email']) ?>"><?= $e($ct['email']) ?></a></div><?php endif; ?>
      </address>
    </div>
<?php endif; ?>
  </div>
  <?php if ($hasMap): ?>
    <iframe class="map" src="<?= $e($ct['map_embed']) ?>" title="Map" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
  <?php endif; ?>
</section>
<?php endif; ?>

<footer class="foot">
  <span>&copy; <?= date('Y') ?> <?= $e($c['name']) ?> &middot; Made &amp; maintained by <a class="tel5-credit" href="https://tel5.com.au" target="_blank" rel="noopener">Tel5</a></span>
  <span>
    <?php foreach ($socialLinks as $label => $url): ?><a href="<?= $e($url) ?>" target="_blank" rel="noopener"><?= $e($label) ?></a>
    <?php endforeach; ?>
    <?= privacy_link($c) ?>
  </span>
</footer>

<?php if ($tabbed): ?>
<script>
(function () {
  var tabs = Array.prototype.slice.call(document.querySelectorAll('.tabs [role=tab]'));
  var panels = Array.prototype.slice.call(document.querySelectorAll('.panel'));
  function show(i, focus) {
    tabs.forEach(function (t, n) {
      t.setAttribute('aria-selected', n === i ? 'true' : 'false');
      t.tabIndex = n === i ? 0 : -1;
    });
    panels.forEach(function (p, n) { p.hidden = n !== i; });
    if (focus) tabs[i].focus();
  }
  tabs.forEach(function (t, n) {
    t.addEventListener('click', function () { show(n); });
    t.addEventListener('keydown', function (ev) {
      if (ev.key === 'ArrowRight') { ev.preventDefault(); show((n + 1) % tabs.length, true); }
      if (ev.key === 'ArrowLeft')  { ev.preventDefault(); show((n - 1 + tabs.length) % tabs.length, true); }
    });
  });
  show(0);
})();
</script>
<?php endif; ?>

<?= body_end($c) ?>
</body>
</html>
