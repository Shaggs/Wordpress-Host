<?php
// Helpers shared by every layout. Included by each layouts/layout-N.php.
if (!isset($c)) { http_response_code(403); exit; }
require_once __DIR__ . '/_embed_buttons.php';

/** Return $v if it is a #RRGGBB colour, otherwise $fallback. */
function safe_hex($v, string $fallback): string
{
    return preg_match('/^#[0-9a-fA-F]{6}$/', (string)$v) ? $v : $fallback;
}

/** Black or white, whichever is easier to read on top of $hex. */
function on_color(string $hex): string
{
    [$r, $g, $b] = array_map(fn($x) => hexdec($x) / 255, str_split(ltrim($hex, '#'), 2));
    $lin = fn($v) => $v <= 0.03928 ? $v / 12.92 : pow(($v + 0.055) / 1.055, 2.4);
    $lum = 0.2126 * $lin($r) + 0.7152 * $lin($g) + 0.0722 * $lin($b);
    return $lum > 0.179 ? '#161616' : '#ffffff';
}

/** The :root block that turns the customer's colours into CSS variables. */
function theme_css(array $c): string
{
    $col = $c['colors'] ?? [];
    $p   = safe_hex($col['primary']    ?? '', '#6F4E37');
    $a   = safe_hex($col['accent']     ?? '', '#D9A441');
    $bg  = safe_hex($col['background'] ?? '', '#FBF7F2');
    $tx  = safe_hex($col['text']       ?? '', '#2B2B2B');
    $sf  = safe_hex($col['surface']    ?? '', '#FFFFFF');
    return ":root{--primary:$p;--accent:$a;--bg:$bg;--text:$tx;--surface:$sf;"
         . '--on-primary:' . on_color($p) . ';--on-accent:' . on_color($a) . ';}';
}

/** Saved ordering/booking URL, or '' if unset or not https. */
function embed_url(array $c, string $key): string
{
    $u = (string)($c['embeds'][$key] ?? '');
    return preg_match('#^https://#i', $u) ? $u : '';
}

/** The iframe for an embedded ordering or booking page, or a button when set to open the provider instead. */
function embed_frame(string $url, string $title, string $class = 'embed-frame'): string
{
    static $cssDone = false;
    $h = fn($s) => htmlspecialchars($s, ENT_QUOTES, 'UTF-8');
    $cfg = $GLOBALS['EMBED_MODES'][$url] ?? null;
    if ($cfg && $cfg['mode'] === 'button') {
        $book  = stripos($title, 'book') === 0;
        $text  = trim((string)$cfg['label']) !== '' ? trim((string)$cfg['label']) : ($book ? 'Book a table' : 'Order online');
        $style = isset(EMBED_BUTTON_STYLES[$cfg['style']]) ? $cfg['style'] : 'solid';
        $o = $cssDone ? '' : '<style>' . EMBED_BUTTON_CSS . '</style>';
        $cssDone = true;
        $inner = $style === 'card'
            ? '<span class="t">' . $h($text) . ' &rarr;</span><span class="sub">Opens in a new tab</span>'
            : $h($text) . ' &rarr;';
        return $o . '<div class="embed-button"><a class="embed-btn s-' . $style . '" href="' . $h($url) . '" target="_blank" rel="noopener" data-track="'
             . ($book ? 'book' : 'order') . '">' . $inner . '</a>' . ($style === 'card' ? '' : '<p>Opens in a new tab.</p>') . '</div>';
    }
    return '<iframe class="' . $h($class) . '" src="' . $h($url) . '" title="' . $h($title) . '"'
         . ' loading="lazy" allow="payment" referrerpolicy="strict-origin-when-cross-origin"'
         . ' sandbox="allow-scripts allow-same-origin allow-forms allow-popups allow-popups-to-escape-sandbox allow-modals allow-top-navigation-by-user-activation">'
         . '</iframe>';
}

require __DIR__ . '/_head.php';

// Menu and hours with empty entries removed. A section with nothing left is hidden.
$menuData  = menu_items($c);
$hoursData = hours_items($c);

// Pictures that really exist on the server. Missing ones are skipped so no blank gaps are left.
$galleryData = array_values(array_filter($c['images']['gallery'] ?? [], 'image_exists'));
$heroImage   = image_exists($c['images']['hero'] ?? '') ? $c['images']['hero'] : '';
$logoImage   = image_exists($c['logo'] ?? '') ? $c['logo'] : '';

// Contact details and social links, with blanks removed. Anything empty is hidden.
$ct         = array_map(fn($v) => trim((string)$v), $c['contact'] ?? []);
$hasAddress = ($ct['address'] ?? '') !== '';
$hasPhone   = ($ct['phone'] ?? '') !== '';
$hasEmail   = ($ct['email'] ?? '') !== '';
$hasMap     = (bool)preg_match('#^https://#i', $ct['map_embed'] ?? '');
$hasContact = $hasAddress || $hasPhone || $hasEmail;
$hasVisit   = $hoursData || $hasContact || $hasMap;
$socialLinks = [];
foreach (['instagram' => 'Instagram', 'facebook' => 'Facebook'] as $k => $label) {
    $u = trim((string)($c['social'][$k] ?? ''));
    if (preg_match('#^https?://#i', $u)) { $socialLinks[$label] = $u; }
}

$e         = fn($s) => htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8');
$orderUrl  = embed_url($c, 'ordering');
$bookUrl   = embed_url($c, 'booking');
$GLOBALS['EMBED_MODES'] = [];
$embedStyle = (string)($c['embeds']['button_style'] ?? 'solid');
if ($bookUrl)  { $GLOBALS['EMBED_MODES'][$bookUrl]  = ['mode' => $c['embeds']['booking_mode']  ?? 'embed', 'label' => $c['embeds']['booking_label']  ?? '', 'style' => $embedStyle]; }
if ($orderUrl) { $GLOBALS['EMBED_MODES'][$orderUrl] = ['mode' => $c['embeds']['ordering_mode'] ?? 'embed', 'label' => $c['embeds']['ordering_label'] ?? '', 'style' => $embedStyle]; }
$phoneHref = 'tel:' . preg_replace('/[^\d+]/', '', (string)($c['contact']['phone'] ?? ''));
