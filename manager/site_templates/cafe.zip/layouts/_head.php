<?php
// <head> extras shared by every layout: SEO tags, structured data and tracking.
if (!isset($c)) { http_response_code(403); exit; }

function h($s): string { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }

/** True if an image path points to a file that really exists on this site (web addresses are trusted). */
function image_exists(?string $path): bool
{
    $path = trim((string)$path);
    if ($path === '') { return false; }
    if (preg_match('#^https?://#i', $path)) { return true; }
    if (strpos($path, '..') !== false) { return false; }
    return is_file(dirname(__DIR__) . '/' . ltrim($path, '/'));
}

/** Picture for link previews and Google: the share image, else the hero photo, else nothing. */
function share_image_path(array $c): string
{
    foreach ([$c['seo']['share_image'] ?? '', $c['images']['hero'] ?? ''] as $p) {
        if (image_exists($p)) { return $p; }
    }
    return '';
}

/** Menu categories that have at least one item. */
function menu_items(array $c): array
{
    return array_filter($c['menu'] ?? [], fn($items) => !empty($items));
}

/** Opening-hours lines that actually have a time filled in. */
function hours_items(array $c): array
{
    return array_filter($c['hours'] ?? [], fn($t) => trim((string)$t) !== '');
}

/** The site's public address (no trailing slash), or '' if not set. */
function site_url(array $c): string { return rtrim((string)($c['seo']['site_url'] ?? ''), '/'); }

/** Turn a stored relative path into an absolute URL; '' if we don't know the site address. */
function abs_url(array $c, ?string $path): string
{
    $base = site_url($c);
    return ($base !== '' && $path) ? $base . '/' . ltrim($path, '/') : '';
}

/** Tracking is skipped while an admin is previewing a layout. */
function tracking_on(): bool { return empty($GLOBALS['site_preview']); }

function img_mime(string $path): string
{
    return ['png' => 'image/png', 'webp' => 'image/webp'][strtolower(pathinfo($path, PATHINFO_EXTENSION))] ?? 'image/jpeg';
}

/** "7:00am" style parts to 24-hour "07:00". */
function to24(string $hr, string $min, string $ap): string
{
    $hr = (int)$hr % 12;
    if (strtolower($ap) === 'pm') { $hr += 12; }
    return sprintf('%02d:%02d', $hr, (int)$min);
}

/** Best-effort conversion of lines like "Mon–Fri | 7:00am – 4:00pm" into schema.org opening hours. */
function parse_hours(array $hours): array
{
    $names = ['mon' => 'Monday', 'tue' => 'Tuesday', 'wed' => 'Wednesday', 'thu' => 'Thursday',
              'fri' => 'Friday', 'sat' => 'Saturday', 'sun' => 'Sunday'];
    $keys = array_keys($names);
    $out  = [];
    foreach ($hours as $label => $time) {
        if (!preg_match('/(\d{1,2})(?::(\d{2}))?\s*(am|pm)?\s*[–—-]\s*(\d{1,2})(?::(\d{2}))?\s*(am|pm)/iu', (string)$time, $t)) {
            continue; // "Closed" or anything we can't read
        }
        $startAp = $t[3] !== '' ? $t[3] : $t[6];
        $opens   = to24($t[1], $t[2] ?: '0', $startAp);
        $closes  = to24($t[4], $t[5] ?: '0', $t[6]);

        $l = mb_strtolower(str_replace(['–', '—'], '-', (string)$label));
        $days = [];
        if (preg_match('/daily|every ?day|7 days/', $l)) {
            $days = $keys;
        } elseif (strpos($l, 'weekday') !== false) {
            $days = array_slice($keys, 0, 5);
        } elseif (strpos($l, 'weekend') !== false) {
            $days = ['sat', 'sun'];
        } elseif (preg_match_all('/\b(mon|tue|wed|thu|fri|sat|sun)[a-z]*/', $l, $d)) {
            $found = $d[1];
            if (count($found) === 2 && (strpos($l, '-') !== false || strpos($l, ' to ') !== false)) {
                $i = array_search($found[0], $keys, true);
                $j = array_search($found[1], $keys, true);
                for ($n = $i; ; $n = ($n + 1) % 7) { $days[] = $keys[$n]; if ($n === $j) break; }
            } else {
                $days = $found;
            }
        }
        if (!$days) { continue; }
        $out[] = [
            '@type'     => 'OpeningHoursSpecification',
            'dayOfWeek' => array_values(array_map(fn($k) => $names[$k], array_unique($days))),
            'opens'     => $opens,
            'closes'    => $closes,
        ];
    }
    return $out;
}

/** schema.org LocalBusiness data built from the existing config. */
function business_schema(array $c): array
{
    $addr = trim((string)($c['contact']['address'] ?? ''));
    if (preg_match('/^(.*),\s*([^,]+?)\s+(NSW|VIC|QLD|SA|WA|TAS|NT|ACT)\s+(\d{4})$/i', $addr, $m)) {
        $address = ['@type' => 'PostalAddress', 'streetAddress' => $m[1], 'addressLocality' => $m[2],
                    'addressRegion' => strtoupper($m[3]), 'postalCode' => $m[4], 'addressCountry' => 'AU'];
    } else {
        $address = ['@type' => 'PostalAddress', 'streetAddress' => $addr, 'addressCountry' => 'AU'];
    }

    $data = [
        '@context'    => 'https://schema.org',
        '@type'       => 'CafeOrCoffeeShop',
        'name'        => $c['name'],
        'description' => trim((string)($c['seo']['description'] ?? '')) ?: $c['about'],
    ];
    if (site_url($c) !== '') { $data['url'] = site_url($c) . '/'; if (menu_items($c)) { $data['hasMenu'] = site_url($c) . '/#menu'; } }
    $img = abs_url($c, share_image_path($c));
    if ($img !== '') { $data['image'] = $img; }
    if (trim((string)($c['contact']['phone'] ?? '')) !== '') { $data['telephone'] = $c['contact']['phone']; }
    if (trim((string)($c['contact']['email'] ?? '')) !== '') { $data['email'] = $c['contact']['email']; }
    if ($addr !== '') { $data['address'] = $address; }
    if ($hours = parse_hours(hours_items($c))) { $data['openingHoursSpecification'] = $hours; }
    if (embed_url($c, 'booking') !== '') { $data['acceptsReservations'] = true; }

    $same = [];
    foreach (($c['social'] ?? []) as $u) {
        $p = parse_url((string)$u);
        if (!empty($p['host']) && !empty($p['path']) && $p['path'] !== '/') { $same[] = $u; }
    }
    if ($same) { $data['sameAs'] = $same; }
    return $data;
}

/** Everything that belongs in <head> apart from the stylesheets. */
function head_tags(array $c): string
{
    $seo   = $c['seo'] ?? [];
    $trk   = $c['tracking'] ?? [];
    $title = trim((string)($seo['title'] ?? '')) ?: $c['name'] . ' — ' . $c['tagline'];
    $desc  = trim((string)($seo['description'] ?? '')) ?: mb_strimwidth(trim((string)$c['about']), 0, 160, '…');
    $url   = site_url($c);
    $share = abs_url($c, share_image_path($c));

    $o  = '<title>' . h($title) . "</title>\n";
    $o .= '  <meta name="description" content="' . h($desc) . "\">\n";
    if ($url !== '') { $o .= '  <link rel="canonical" href="' . h($url) . "/\">\n"; }
    if (!empty($seo['search_console'])) {
        $o .= '  <meta name="google-site-verification" content="' . h($seo['search_console']) . "\">\n";
    }
    if (image_exists($seo['favicon'] ?? '')) {
        $o .= '  <link rel="icon" type="' . img_mime($seo['favicon']) . '" href="' . h($seo['favicon']) . "\">\n";
    }

    // Link previews (Facebook, WhatsApp, iMessage, etc.)
    $o .= '  <meta property="og:type" content="website">' . "\n";
    $o .= '  <meta property="og:title" content="' . h($title) . "\">\n";
    $o .= '  <meta property="og:description" content="' . h($desc) . "\">\n";
    $o .= '  <meta property="og:site_name" content="' . h($c['name']) . "\">\n";
    if ($url !== '')   { $o .= '  <meta property="og:url" content="' . h($url) . "/\">\n"; }
    if ($share !== '') { $o .= '  <meta property="og:image" content="' . h($share) . "\">\n"
                             . '  <meta name="twitter:card" content="summary_large_image">' . "\n"; }

    // Start loading the main photo straight away (helps page speed, which Google measures)
    if (image_exists($c['images']['hero'] ?? '')) {
        $o .= '  <link rel="preload" as="image" href="' . h($c['images']['hero']) . "\" fetchpriority=\"high\">\n";
    }

    // Structured data for Google (name, address, hours, etc.)
    $json = json_encode(business_schema($c), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP);
    $o .= '  <script type="application/ld+json">' . $json . "</script>\n";

    if (!tracking_on()) { return $o; }

    // Tracking. With Google Tag Manager, GA4/Ads are managed inside GTM, so we don't also load them directly.
    if (!empty($trk['gtm'])) {
        $id = h($trk['gtm']);
        $o .= "  <script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':new Date().getTime(),event:'gtm.js'});"
            . "var f=d.getElementsByTagName(s)[0],j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;"
            . "j.src='https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);})"
            . "(window,document,'script','dataLayer','$id');</script>\n";
    } elseif (!empty($trk['ga4']) || !empty($trk['gads'])) {
        $first = $trk['ga4'] ?: $trk['gads'];
        $o .= '  <script async src="https://www.googletagmanager.com/gtag/js?id=' . h($first) . "\"></script>\n";
        $o .= "  <script>window.dataLayer=window.dataLayer||[];function gtag(){dataLayer.push(arguments);}gtag('js',new Date());";
        foreach (['ga4', 'gads'] as $k) {
            if (!empty($trk[$k])) { $o .= "gtag('config','" . h($trk[$k]) . "');"; }
        }
        $o .= "</script>\n";
    }
    if (!empty($trk['meta_pixel'])) {
        $id = h($trk['meta_pixel']);
        $o .= "  <script>!function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?n.callMethod.apply(n,arguments):n.queue.push(arguments)};"
            . "if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;"
            . "t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,document,'script','https://connect.facebook.net/en_US/fbevents.js');"
            . "fbq('init','$id');fbq('track','PageView');</script>\n";
    }
    return $o;
}

/** Goes straight after <body>: the no-JavaScript fallbacks for GTM and Meta Pixel. */
function body_start(array $c): string
{
    if (!tracking_on()) { return ''; }
    $trk = $c['tracking'] ?? [];
    $o = '';
    if (!empty($trk['gtm'])) {
        $o .= '<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=' . h($trk['gtm'])
            . '" height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>' . "\n";
    }
    if (!empty($trk['meta_pixel'])) {
        $o .= '<noscript><img height="1" width="1" style="display:none" alt="" src="https://www.facebook.com/tr?id='
            . h($trk['meta_pixel']) . '&ev=PageView&noscript=1"></noscript>' . "\n";
    }
    return $o;
}

/** Goes just before </body>: reports taps on Order / Book / Call buttons. */
function body_end(array $c): string
{
    $trk = $c['tracking'] ?? [];
    if (!tracking_on() || !(($trk['gtm'] ?? '') || ($trk['ga4'] ?? '') || ($trk['gads'] ?? ''))) { return ''; }
    $conv = (!empty($trk['gads']) && !empty($trk['gads_label'])) ? $trk['gads'] . '/' . $trk['gads_label'] : '';
    $conv = json_encode($conv, JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP);
    return <<<HTML
<script>
document.addEventListener('click', function (e) {
  var a = e.target.closest && e.target.closest('[data-track]');
  if (!a) return;
  var name = a.getAttribute('data-track') + '_click', conv = $conv;
  if (typeof gtag === 'function') {
    gtag('event', name);
    if (conv) gtag('event', 'conversion', { send_to: conv });
  } else if (window.dataLayer) {
    window.dataLayer.push({ event: name });
  }
});
</script>

HTML;
}

/** Footer link to the cafe's privacy policy, if they've set one. */
function privacy_link(array $c): string
{
    $u = trim((string)($c['tracking']['privacy_url'] ?? ''));
    return $u === '' ? '' : '<a href="' . h($u) . '">Privacy policy</a>';
}
