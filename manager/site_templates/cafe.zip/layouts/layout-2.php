<?php
require __DIR__ . '/_shared.php';
$gallery  = $galleryData;
$firstDay = array_key_first($hoursData);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <?= head_tags($c) ?>
  <link rel="stylesheet" href="assets/css/layout-2.css?v=<?= @filemtime(__DIR__ . '/../assets/css/layout-2.css') ?>">
  <style><?= theme_css($c) ?></style>
</head>
<body>
<?= body_start($c) ?>

<header class="top">
  <div class="wrap top-inner">
    <?php if ($logoImage): ?>
      <a href="#" class="brand"><img src="<?= $e($logoImage) ?>" alt="<?= $e($c['name']) ?>"></a>
    <?php else: ?>
      <a href="#" class="brand"><?= $e($c['name']) ?></a>
    <?php endif; ?>
    <nav aria-label="Main">
      <a href="#about">About</a>
      <?php if ($menuData): ?><a href="#menu">Menu</a><?php endif; ?>
      <?php if ($orderUrl): ?><a href="#order">Order</a><?php endif; ?>
      <?php if ($bookUrl): ?><a href="#book">Book</a><?php endif; ?>
      <?php if ($hasVisit): ?><a href="#visit">Visit</a><?php endif; ?>
    </nav>
  </div>
</header>

<section class="hero<?= $heroImage ? '' : ' hero-noimg' ?>">
  <div class="hero-copy">
    <h1><?= $e($c['name']) ?></h1>
    <p class="hero-tag"><?= $e($c['tagline']) ?></p>
    <div class="hero-actions">
      <?php if ($orderUrl): ?><a class="btn" href="#order" data-track="order">Order online</a><?php endif; ?>
      <?php if ($bookUrl): ?><a class="btn btn-ghost" href="#book" data-track="book">Book a table</a><?php endif; ?>
      <?php if (!$orderUrl && !$bookUrl && $hasVisit): ?><a class="btn" href="#visit">Visit us</a><?php endif; ?>
    </div>
    <?php if ($firstDay): ?>
      <p class="hero-hours"><?= $e($firstDay) ?>, <?= $e($hoursData[$firstDay]) ?></p>
    <?php endif; ?>
  </div>
  <?php if ($heroImage): ?>
  <div class="hero-img" role="img" aria-label="<?= $e($c['name']) ?>"
       style="background-image: url('<?= $e($heroImage) ?>');"></div>
  <?php endif; ?>
</section>

<section id="about" class="block wrap split">
  <h2>Our story</h2>
  <p class="story"><?= $e($c['about']) ?></p>
</section>

<?php if ($menuData): ?>
<section id="menu" class="menu-panel">
  <div class="wrap">
    <h2>Menu</h2>
    <div class="menu-cols">
      <?php foreach ($menuData as $category => $items): ?>
        <div class="menu-cat">
          <h3><?= $e($category) ?></h3>
          <ul>
            <?php foreach ($items as $row): ?>
              <li><span class="dish"><?= $e($row['item']) ?></span><span class="dots" aria-hidden="true"></span><span class="price"><?= $e($row['price']) ?></span></li>
            <?php endforeach; ?>
          </ul>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>
<?php endif; ?>

<?php if ($orderUrl): ?>
<section id="order" class="block wrap service">
  <div class="service-intro">
    <h2>Order online</h2>
    <p>Order ahead and skip the queue.</p>
    <a href="<?= $e($orderUrl) ?>" target="_blank" rel="noopener">Open in a new tab</a>
  </div>
  <?= embed_frame($orderUrl, 'Order online from ' . $c['name']) ?>
</section>
<?php endif; ?>

<?php if ($gallery): ?>
<section id="gallery" class="block wrap">
  <h2 class="sr-only">Gallery</h2>
  <div class="mosaic <?= count($gallery) === 3 ? 'mosaic-3' : 'mosaic-even' ?>">
    <?php foreach ($gallery as $img): ?>
      <img src="<?= $e($img) ?>" alt="<?= $e($c['name']) ?> photo" loading="lazy" onerror="this.style.opacity=0">
    <?php endforeach; ?>
  </div>
</section>
<?php endif; ?>

<?php if ($bookUrl): ?>
<section id="book" class="block wrap service">
  <div class="service-intro">
    <h2>Book a table</h2>
    <p>Pick a day and time that suits you.</p>
    <a href="<?= $e($bookUrl) ?>" target="_blank" rel="noopener">Open in a new tab</a>
  </div>
  <?= embed_frame($bookUrl, 'Book a table at ' . $c['name']) ?>
</section>
<?php endif; ?>

<?php if ($hasVisit): ?>
<section id="visit" class="visit">
  <div class="wrap visit-grid">
<?php if ($hoursData): ?>
    <div>
      <h2>Opening hours</h2>
      <ul class="hours">
        <?php foreach ($hoursData as $day => $time): ?>
          <li><span><?= $e($day) ?></span><span><?= $e($time) ?></span></li>
        <?php endforeach; ?>
      </ul>
    </div>
<?php endif; ?>
<?php if ($hasContact): ?>
    <div>
      <h2>Find us</h2>
      <address>
        <?php if ($hasAddress): ?><div><?= $e($ct['address']) ?></div><?php endif; ?>
        <?php if ($hasPhone): ?><div><a href="<?= $e($phoneHref) ?>" data-track="call"><?= $e($ct['phone']) ?></a></div><?php endif; ?>
        <?php if ($hasEmail): ?><div><a href="mailto:<?= $e($ct['email']) ?>"><?= $e($ct['email']) ?></a></div><?php endif; ?>
      </address>
    </div>
<?php endif; ?>
    <?php if ($hasMap): ?>
      <iframe class="map" src="<?= $e($ct['map_embed']) ?>" title="Map" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
    <?php endif; ?>
  </div>
</section>
<?php endif; ?>

<footer class="foot">
  <div class="wrap foot-inner">
    <span>&copy; <?= date('Y') ?> <?= $e($c['name']) ?> &middot; Made &amp; maintained by <a class="tel5-credit" href="https://tel5.com.au" target="_blank" rel="noopener">Tel5</a></span>
    <span>
      <?php foreach ($socialLinks as $label => $url): ?><a href="<?= $e($url) ?>" target="_blank" rel="noopener"><?= $e($label) ?></a>
      <?php endforeach; ?>
      <?= privacy_link($c) ?>
    </span>
  </div>
</footer>

<?= body_end($c) ?>
</body>
</html>
