<?php
// Picks the layout chosen in the admin dashboard and renders it.
$c       = require __DIR__ . '/config.php';
$layouts = require __DIR__ . '/layouts/registry.php';

$layout = (int)($c['layout'] ?? 1);

// Logged-in admins can try a layout without saving: index.php?preview=2
if (isset($_GET['preview']) && isset($_COOKIE[session_name()])) {
    session_start(['read_and_close' => true]);
    $try = (int)$_GET['preview'];
    if (!empty($_SESSION['admin_ok']) && isset($layouts[$try])) {
        $layout = $try;
        $GLOBALS['site_preview'] = true; // don't count admin previews in analytics
    }
}

if (!isset($layouts[$layout])) {
    $layout = 1;
}

require __DIR__ . "/layouts/layout-$layout.php";
