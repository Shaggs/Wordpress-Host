<?php
// Admins only: add users, change roles, set anyone's password, remove users.
require __DIR__ . '/auth.php';
require_admin();

$msg   = (string)($_GET['msg'] ?? '');
$error = '';
$users = load_users();
$me    = current_user();

function back(string $msg): void
{
    header('Location: team.php?msg=' . rawurlencode($msg));
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    check_csrf();
    $action = $_POST['action'] ?? '';
    $name   = trim($_POST['username'] ?? '');
    $role   = $_POST['role'] ?? '';
    $pw     = $_POST['password'] ?? '';

    try {
        if ($action === 'add') {
            $exists = false;
            foreach (array_keys($users) as $u) {
                if (strcasecmp($u, $name) === 0) {
                    $exists = true;
                }
            }
            if (!valid_username($name)) {
                $error = 'Usernames are 3 to 40 characters: letters, numbers, dot, dash or underscore.';
            } elseif ($exists) {
                $error = 'There is already a user called ' . $name . '.';
            } elseif (!isset(ROLES[$role])) {
                $error = 'Choose a role.';
            } elseif ($problem = password_problem($pw)) {
                $error = $problem;
            } else {
                $users[$name] = ['hash' => password_hash($pw, PASSWORD_DEFAULT), 'role' => $role, 'changed' => microtime(true)];
                save_users($users);
                back('Added ' . $name . ' as ' . ROLES[$role] . '.');
            }
        } elseif (!isset($users[$name])) {
            $error = 'That user no longer exists.';
        } elseif ($action === 'role') {
            if (!isset(ROLES[$role])) {
                $error = 'Choose a role.';
            } elseif ($users[$name]['role'] === 'admin' && $role !== 'admin' && admin_count($users) <= 1) {
                $error = 'There must always be at least one admin.';
            } else {
                $users[$name]['role'] = $role;
                save_users($users);
                if ($name === $me && $role !== 'admin') {
                    $_SESSION['admin_role'] = $role;
                    header('Location: dashboard.php');
                    exit;
                }
                back($name . ' is now ' . ROLES[$role] . '.');
            }
        } elseif ($action === 'password') {
            if ($problem = password_problem($pw)) {
                $error = $problem;
            } else {
                $now = microtime(true);
                $users[$name]['hash']    = password_hash($pw, PASSWORD_DEFAULT);
                $users[$name]['changed'] = $now;
                save_users($users);
                if ($name === $me) {
                    session_regenerate_id(true);
                    $_SESSION['admin_since'] = $now;
                }
                back('Password changed for ' . $name . '. They are signed out until they use the new one.');
            }
        } elseif ($action === 'delete') {
            if ($name === $me) {
                $error = 'You cannot remove your own account.';
            } elseif ($users[$name]['role'] === 'admin' && admin_count($users) <= 1) {
                $error = 'There must always be at least one admin.';
            } else {
                unset($users[$name]);
                save_users($users);
                back('Removed ' . $name . '.');
            }
        } else {
            $error = 'Unknown action.';
        }
    } catch (RuntimeException $ex) {
        $error = $ex->getMessage();
    }
    $users = load_users();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="robots" content="noindex">
  <title>Users — Admin</title>
  <link rel="stylesheet" href="admin.css">
</head>
<body>
<?= admin_bar() ?>
<main class="admin-main">
  <?php if ($msg !== ''): ?><p class="alert success"><?= e($msg) ?></p><?php endif; ?>
  <?php if ($error): ?><p class="alert error"><?= e($error) ?></p><?php endif; ?>

  <section class="card">
    <h2>Users</h2>
    <p class="hint"><strong>Admin</strong>: edits the site and manages users. <strong>Editor</strong>: edits the site only. Everyone can change their own password under My password.</p>
    <div class="user-list">
    <?php foreach ($users as $name => $u): ?>
      <div class="user-row">
        <div class="user-name"><strong><?= e($name) ?></strong><?= $name === $me ? ' <span class="hint">(you)</span>' : '' ?></div>
        <form method="post" class="user-act">
          <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
          <input type="hidden" name="action" value="role">
          <input type="hidden" name="username" value="<?= e($name) ?>">
          <select name="role" aria-label="Role for <?= e($name) ?>">
            <?php foreach (ROLES as $k => $label): ?>
              <option value="<?= e($k) ?>"<?= $u['role'] === $k ? ' selected' : '' ?>><?= e($label) ?></option>
            <?php endforeach; ?>
          </select>
          <button type="submit" class="btn-small">Save role</button>
        </form>
        <form method="post" class="user-act">
          <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
          <input type="hidden" name="action" value="password">
          <input type="hidden" name="username" value="<?= e($name) ?>">
          <input type="password" name="password" placeholder="New password" minlength="8" maxlength="128" required autocomplete="new-password" aria-label="New password for <?= e($name) ?>">
          <button type="submit" class="btn-small">Set password</button>
        </form>
        <?php if ($name !== $me): ?>
        <form method="post" class="user-act" onsubmit="return confirm(<?= e(json_encode('Remove ' . $name . '? They will no longer be able to sign in.')) ?>);">
          <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
          <input type="hidden" name="action" value="delete">
          <input type="hidden" name="username" value="<?= e($name) ?>">
          <button type="submit" class="btn-small danger">Remove</button>
        </form>
        <?php endif; ?>
      </div>
    <?php endforeach; ?>
    </div>
  </section>

  <form method="post" class="card">
    <h2>Add a user</h2>
    <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
    <input type="hidden" name="action" value="add">
    <div class="field-row">
      <label>Username <span class="hint">(letters, numbers, . - _)</span>
        <input type="text" name="username" required minlength="3" maxlength="40" pattern="[A-Za-z0-9._\-]{3,40}" autocomplete="off">
      </label>
      <label>Role
        <select name="role">
          <option value="editor">Editor — edits the site only</option>
          <option value="admin">Admin — edits the site and manages users</option>
        </select>
      </label>
    </div>
    <label>Password <span class="hint">(at least 8 characters; give it to them privately)</span>
      <input type="password" name="password" required minlength="8" maxlength="128" autocomplete="new-password">
    </label>
    <button type="submit" class="btn-primary">Add user</button>
  </form>
</main>
</body>
</html>
