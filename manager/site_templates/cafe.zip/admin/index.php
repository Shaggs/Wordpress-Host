<?php
// Visiting /admin/ lands here. Send logged-in users to the dashboard
// and everyone else to the login page.
require __DIR__ . '/auth.php';

if (!empty($_SESSION['admin_ok'])) {
    header('Location: dashboard.php');
} else {
    header('Location: login.php');
}
exit;
