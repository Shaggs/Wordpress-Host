<?php
// Any signed-in user can change their own password here.
require __DIR__ . '/auth.php';
require_login();

$error = '';
$done  = isset($_GET['done']);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    check_csrf();
    $users   = load_users();
    $me      = current_user();
    $current = $_POST['current'] ?? '';
    $new     = $_POST['new'] ?? '';
    $confirm = $_POST['confirm'] ?? '';

    if (!isset($users[$me]) || !password_verify($current, $users[$me]['hash'])) {
        usleep(500000);
        $error = 'Your current password is not correct.';
    } elseif ($problem = password_problem($new)) {
        $error = $problem;
    } elseif (!hash_equals($new, $confirm)) {
        $error = 'The two new passwords do not match.';
    } else {
        try {
            $now = microtime(true);
            $users[$me]['hash']    = password_hash($new, PASSWORD_DEFAULT);
            $users[$me]['changed'] = $now;
            save_users($users);
            // Keep this session; any other session for this account is signed out.
            session_regenerate_id(true);
            $_SESSION['admin_since'] = $now;
            header('Location: account.php?done=1');
            exit;
        } catch (RuntimeException $ex) {
            $error = $ex->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="robots" content="noindex">
  <title>My password — Admin</title>
  <link rel="stylesheet" href="admin.css">
</head>
<body>
<?= admin_bar() ?>
<main class="admin-main narrow">
  <?php if ($done): ?><p class="alert success">Your password has been changed.</p><?php endif; ?>
  <?php if ($error): ?><p class="alert error"><?= e($error) ?></p><?php endif; ?>
  <form method="post" class="card">
    <h2>My password</h2>
    <p class="hint">Signed in as <strong><?= e(current_user()) ?></strong>. Changing your password signs you out everywhere else.</p>
    <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
    <label>Current password
      <input type="password" name="current" required autocomplete="current-password">
    </label>
    <label>New password <span class="hint">(at least 8 characters)</span>
      <input type="password" name="new" required minlength="8" maxlength="128" autocomplete="new-password">
    </label>
    <label>New password again
      <input type="password" name="confirm" required minlength="8" maxlength="128" autocomplete="new-password">
    </label>
    <button type="submit" class="btn-primary">Change password</button>
  </form>
</main>
</body>
</html>
