<?php
require __DIR__ . '/auth.php';
require_once dirname(__DIR__) . '/layouts/_embed_buttons.php';
require_login();

$c = require ROOT . '/config.php';
$layouts = require ROOT . '/layouts/registry.php';
$error = '';

function parse_menu(string $text): array
{
    $menu = [];
    foreach (preg_split('/\r\n|\r|\n/', $text) as $line) {
        $p = array_map('trim', explode('|', $line, 3));
        if (count($p) === 3 && $p[0] !== '' && $p[1] !== '') {
            $menu[$p[0]][] = ['item' => $p[1], 'price' => $p[2]];
        }
    }
    return $menu;
}

function parse_pairs(string $text): array
{
    $out = [];
    foreach (preg_split('/\r\n|\r|\n/', $text) as $line) {
        $p = array_map('trim', explode('|', $line, 2));
        if (count($p) === 2 && $p[0] !== '' && $p[1] !== '') {
            $out[$p[0]] = $p[1];
        }
    }
    return $out;
}

function menu_to_text(array $menu): string
{
    $lines = [];
    foreach ($menu as $cat => $items) {
        foreach ($items as $row) {
            $lines[] = "$cat | {$row['item']} | {$row['price']}";
        }
    }
    return implode("\n", $lines);
}

function pairs_to_text(array $pairs): string
{
    $lines = [];
    foreach ($pairs as $k => $v) {
        $lines[] = "$k | $v";
    }
    return implode("\n", $lines);
}

function post_text(string $key, int $max = 200): string
{
    return mb_substr(trim($_POST[$key] ?? ''), 0, $max);
}

const GALLERY_SLOTS = 3;

/** True if an image path points to a real file (so the admin never shows a broken preview). */
function photo_ok(?string $path): bool
{
    $path = trim((string)$path);
    return $path !== '' && strpos($path, '..') === false && is_file(ROOT . '/' . ltrim($path, '/'));
}

/** One upload tile: title, preview (or empty box), optional Remove tick, file picker. Shape: wide, square or logo. */
function photo_tile(string $title, string $hint, ?string $path, string $input, ?string $remove = null, string $shape = 'wide'): string
{
    $ok = photo_ok($path);
    $o  = '<div class="tile"><p class="field-title">' . e($title) . ($hint !== '' ? ' <span class="hint">' . e($hint) . '</span>' : '') . '</p>';
    $o .= '<div class="thumb-box thumb-' . $shape . ($ok ? '' : ' thumb-empty') . '">';
    $o .= $ok ? '<img src="../' . e($path) . '" alt="">' : '<span>No photo</span>';
    $o .= '</div>';
    if ($ok && $remove) {
        $o .= '<label class="inline"><input type="checkbox" name="' . e($remove) . '" value="1"> Remove</label>';
    }
    return $o . '<input type="file" name="' . e($input) . '" accept="image/jpeg,image/png,image/webp"></div>';
}

function save_upload(string $field, string $slot, ?string $label = null): ?string
{
    $label = $label ?? $slot;
    if (($_FILES[$field]['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) {
        return null;
    }
    if ($_FILES[$field]['error'] !== UPLOAD_ERR_OK) {
        throw new RuntimeException("The $label upload failed. Please try a smaller file.");
    }
    $tmp = $_FILES[$field]['tmp_name'];
    if ($_FILES[$field]['size'] > 5 * 1024 * 1024) {
        throw new RuntimeException("The $label must be under 5 MB.");
    }

    $info = @getimagesize($tmp);
    $types = [IMAGETYPE_JPEG => 'jpg', IMAGETYPE_PNG => 'png', IMAGETYPE_WEBP => 'webp'];
    if (!$info || !isset($types[$info[2]])) {
        throw new RuntimeException("The $label must be a JPG, PNG or WebP image.");
    }

    $rel = 'assets/images/' . $slot . '-' . time() . '.' . $types[$info[2]];
    if (!@move_uploaded_file($tmp, ROOT . '/' . $rel)) {
        throw new RuntimeException('Could not save the uploaded image. Check folder permissions.');
    }
    return $rel;
}

/**
 * Accepts an https:// link, or a pasted <iframe ... src="..."> snippet
 * (the src address is pulled out). Blank is allowed and hides the section.
 */
function clean_embed_url(string $raw, string $label): string
{
    $raw = trim($raw);
    if ($raw === '') {
        return '';
    }
    if (stripos($raw, '<iframe') !== false) {
        if (!preg_match('/\bsrc\s*=\s*["\']([^"\']+)["\']/i', $raw, $m)) {
            throw new RuntimeException("Could not find a link inside the $label embed code.");
        }
        $raw = html_entity_decode(trim($m[1]), ENT_QUOTES, 'UTF-8');
    }
    if (!preg_match('#^https://#i', $raw) || !filter_var($raw, FILTER_VALIDATE_URL)) {
        throw new RuntimeException("The $label link must be a full address starting with https://");
    }
    return $raw;
}

/**
 * True if the provider's page refuses to be shown inside another website
 * (X-Frame-Options, or a Content-Security-Policy frame-ancestors rule that leaves us out).
 * If the check cannot be done, returns false and the page stays embedded.
 */
function embed_blocked(string $url): bool
{
    $ctx = stream_context_create(['http' => [
        'method' => 'GET', 'timeout' => 6, 'ignore_errors' => true, 'follow_location' => 1, 'max_redirects' => 5,
        'header' => "User-Agent: Mozilla/5.0 (site editor embed check)\r\n",
    ]]);
    $headers = @get_headers($url, true, $ctx);
    if (!$headers) {
        return false;
    }
    $h = array_change_key_case($headers, CASE_LOWER);
    $last = fn($v) => is_array($v) ? (string)end($v) : (string)$v;
    $xfo = strtolower(trim($last($h['x-frame-options'] ?? '')));
    if ($xfo === 'deny' || $xfo === 'sameorigin') {
        return true;
    }
    $csp = strtolower($last($h['content-security-policy'] ?? ''));
    if (preg_match('/frame-ancestors([^;]*)/', $csp, $m)) {
        $allowed = trim($m[1]);
        $host = strtolower((string)($_SERVER['HTTP_HOST'] ?? ''));
        if (strpos($allowed, '*') === false && ($host === '' || strpos($allowed, $host) === false)) {
            return true;
        }
    }
    return false;
}

/** Checks an analytics/advertising ID against its expected shape. Blank is allowed (turns it off). */
function clean_id(string $raw, string $pattern, string $label, string $example): string
{
    $raw = strtoupper(trim($raw));
    if ($raw === '') {
        return '';
    }
    if (!preg_match($pattern, $raw)) {
        throw new RuntimeException("$label doesn't look right. It should look like $example.");
    }
    return $raw;
}

function clean_site_url(string $raw): string
{
    $raw = rtrim(trim($raw), '/');
    if ($raw === '') {
        return '';
    }
    $p = parse_url($raw);
    if (!$p || !in_array($p['scheme'] ?? '', ['http', 'https'], true) || empty($p['host']) || isset($p['query'])) {
        throw new RuntimeException('Website address must look like https://www.yourcafe.com.au');
    }
    return $raw;
}

/** Accepts the verification code, or the whole <meta ...> tag Google gives you. */
function clean_verification(string $raw): string
{
    $raw = trim($raw);
    if ($raw === '') {
        return '';
    }
    if (preg_match('/content\s*=\s*["\']([^"\']+)["\']/i', $raw, $m)) {
        $raw = $m[1];
    }
    if (!preg_match('/^[A-Za-z0-9_-]{20,100}$/', $raw)) {
        throw new RuntimeException("The Search Console code doesn't look right. Paste the code or the whole meta tag from Google.");
    }
    return $raw;
}

/** Full https:// link, or a path on this site such as /privacy.html. */
function clean_link(string $raw, string $label): string
{
    $raw = trim($raw);
    if ($raw === '') {
        return '';
    }
    $ok = (preg_match('#^https://#i', $raw) && filter_var($raw, FILTER_VALIDATE_URL))
       || (preg_match('#^/(?!/)[^\s]*$#', $raw));
    if (!$ok) {
        throw new RuntimeException("$label must start with https:// or be a path like /privacy.html");
    }
    return $raw;
}

function write_config(array $data): void
{
    $file = ROOT . '/config.php';
    $php  = "<?php\n// Last saved from the admin dashboard: " . date('Y-m-d H:i') . "\n"
          . 'return ' . var_export($data, true) . ";\n";

    $tmp = $file . '.tmp';
    if (is_writable(ROOT) && @file_put_contents($tmp, $php, LOCK_EX) !== false) {
        // Safest method: write a temp file, then swap it in.
        rename($tmp, $file);
    } elseif (is_writable($file)) {
        // The folder is locked down, but config.php itself is writable: write to it directly.
        if (@file_put_contents($file, $php, LOCK_EX) === false) {
            throw new RuntimeException('Could not write config.php. Check file permissions.');
        }
    } else {
        throw new RuntimeException('Could not write config.php. Check file permissions.');
    }

    // Make PHP's opcache pick up the new settings immediately instead of after a short delay.
    if (function_exists('opcache_invalidate')) {
        @opcache_invalidate($file, true);
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    check_csrf();

    $new = $c;
    try {
        $chosen = (int)($_POST['layout'] ?? 0);
        if (!isset($layouts[$chosen])) {
            throw new RuntimeException('Please choose one of the site layouts.');
        }
        $new['layout'] = $chosen;

        $new['name']    = post_text('name', 80);
        $new['tagline'] = post_text('tagline', 140);
        $new['about']   = post_text('about', 1000);

        foreach (['primary', 'accent', 'background', 'text', 'surface'] as $key) {
            $v = trim($_POST['color_' . $key] ?? '');
            if (!preg_match('/^#[0-9a-fA-F]{6}$/', $v)) {
                throw new RuntimeException("Colour '$key' must be a hex value like #6F4E37.");
            }
            $new['colors'][$key] = $v;
        }

        $new['menu']  = parse_menu($_POST['menu'] ?? '');
        $new['hours'] = parse_pairs($_POST['hours'] ?? '');

        $email = post_text('email', 120);
        if ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            throw new RuntimeException('Please enter a valid email address.');
        }
        $new['contact'] = [
            'address'   => post_text('address', 200),
            'phone'     => post_text('phone', 40),
            'email'     => $email,
            'map_embed' => post_text('map_embed', 500),
        ];

        $embedNotices = [];
        foreach (['ordering' => 'online ordering', 'booking' => 'booking'] as $key => $label) {
            $raw = post_text('embed_' . $key, 1500);
            $new['embeds'][$key] = $raw;                 // keep what they typed if validation fails
            $new['embeds'][$key] = clean_embed_url($raw, $label);
            $mode = empty($_POST['embed_' . $key . '_button']) ? 'embed' : 'button';
            if ($new['embeds'][$key] !== '' && $mode === 'embed' && embed_blocked($new['embeds'][$key])) {
                $mode = 'button';
                $embedNotices[] = ucfirst($label) . ": that provider does not allow its page to be shown inside other websites, so your site now shows a button that opens it instead.";
            }
            $new['embeds'][$key . '_mode'] = $mode;
            $new['embeds'][$key . '_label'] = post_text('embed_' . $key . '_label', 40);
        }
        $bs = (string)($_POST['embed_button_style'] ?? 'solid');
        $new['embeds']['button_style'] = isset(EMBED_BUTTON_STYLES[$bs]) ? $bs : 'solid';

        $seo = $new['seo'] ?? [];
        $seo['title']          = post_text('seo_title', 70);
        $seo['description']    = post_text('seo_description', 160);
        $seo['site_url']       = post_text('seo_site_url', 200);
        $seo['search_console'] = post_text('seo_search_console', 300);
        $new['seo'] = $seo;
        $new['seo']['site_url']       = clean_site_url($seo['site_url']);
        $new['seo']['search_console'] = clean_verification($seo['search_console']);

        $trk = $new['tracking'] ?? [];
        $trk['ga4']         = post_text('trk_ga4', 30);
        $trk['gads']        = post_text('trk_gads', 30);
        $trk['gads_label']  = post_text('trk_gads_label', 60);
        $trk['gtm']         = post_text('trk_gtm', 30);
        $trk['meta_pixel']  = post_text('trk_meta_pixel', 30);
        $trk['privacy_url'] = post_text('trk_privacy_url', 300);
        $new['tracking'] = $trk;
        $new['tracking']['ga4']        = clean_id($trk['ga4'],  '/^G-[A-Z0-9]{4,14}$/',   'The Google Analytics ID', 'G-ABC123XYZ4');
        $new['tracking']['gads']       = clean_id($trk['gads'], '/^AW-\d{6,12}$/',        'The Google Ads ID', 'AW-123456789');
        $new['tracking']['gtm']        = clean_id($trk['gtm'],  '/^GTM-[A-Z0-9]{4,10}$/', 'The Tag Manager ID', 'GTM-ABC123');
        $new['tracking']['meta_pixel'] = clean_id($trk['meta_pixel'], '/^\d{8,20}$/',      'The Meta Pixel ID', '1234567890123456');
        $label = trim($trk['gads_label']);
        if ($label !== '' && !preg_match('/^[A-Za-z0-9_-]{6,60}$/', $label)) {
            throw new RuntimeException("The Google Ads conversion label doesn't look right. It's the part after the slash in your conversion ID.");
        }
        $new['tracking']['gads_label']  = $label;
        $new['tracking']['privacy_url'] = clean_link($trk['privacy_url'], 'The privacy policy link');

        $new['social'] = [
            'instagram' => post_text('instagram', 200),
            'facebook'  => post_text('facebook', 200),
        ];

        if ($path = save_upload('hero_upload', 'hero')) {
            $new['images']['hero'] = $path;
        }
        if ($path = save_upload('logo_upload', 'logo')) {
            $new['logo'] = $path;
        }
        if ($path = save_upload('share_upload', 'share')) {
            $new['seo']['share_image'] = $path;
        }
        if ($path = save_upload('favicon_upload', 'favicon')) {
            $new['seo']['favicon'] = $path;
        }
        if (($_POST['remove_share'] ?? '') === '1') {
            $new['seo']['share_image'] = null;
        }
        if (($_POST['remove_favicon'] ?? '') === '1') {
            $new['seo']['favicon'] = null;
        }
        if (($_POST['remove_logo'] ?? '') === '1') {
            $new['logo'] = null;
        }

        // Gallery: three fixed slots. A new upload replaces the photo, "Remove" empties the slot.
        $current = array_values($new['images']['gallery'] ?? []);
        $slots = [];
        for ($i = 0; $i < GALLERY_SLOTS; $i++) {
            $photo = (string)($current[$i] ?? '');
            if ($path = save_upload("gallery_upload_$i", 'gallery' . ($i + 1), 'gallery photo ' . ($i + 1))) {
                $photo = $path;
            } elseif (($_POST["remove_gallery_$i"] ?? '') === '1') {
                $photo = '';
            }
            $slots[] = $photo;
        }
        $new['images']['gallery'] = $slots;

        write_config($new);
        $_SESSION['embed_notice'] = $embedNotices ?? [];
        header('Location: dashboard.php?saved=1');
        exit;
    } catch (RuntimeException $ex) {
        $error = $ex->getMessage();
        $c = $new;
    }
}

$saved = isset($_GET['saved']);
$currentLayout = (int)($c['layout'] ?? 1);

/** Tiny wireframe so each layout is recognisable at a glance. */
function layout_icon(int $id): string
{
    $o = 'fill="currentColor"';
    $l = 'fill="currentColor" opacity=".25"';
    $shapes = [
        1 => "<rect x='2' y='2' width='116' height='6' $l/><rect x='14' y='14' width='92' height='26' $o opacity='.55'/>"
           . "<rect x='38' y='22' width='44' height='4' fill='#fff'/><rect x='14' y='46' width='28' height='18' $l/>"
           . "<rect x='46' y='46' width='28' height='18' $l/><rect x='78' y='46' width='28' height='18' $l/>"
           . "<rect x='14' y='68' width='92' height='10' $l/>",
        2 => "<rect x='2' y='2' width='116' height='6' $l/><rect x='2' y='12' width='48' height='36' $o/>"
           . "<rect x='8' y='24' width='30' height='5' fill='#fff'/><rect x='50' y='12' width='68' height='36' $o opacity='.45'/>"
           . "<rect x='2' y='52' width='116' height='12' $o opacity='.8'/><rect x='2' y='68' width='56' height='10' $l/>"
           . "<rect x='62' y='68' width='56' height='10' $l/>",
        3 => "<rect x='2' y='2' width='116' height='42' $o opacity='.55'/><rect x='8' y='30' width='60' height='8' fill='#fff'/>"
           . "<rect x='2' y='46' width='116' height='8' $o opacity='.8'/><rect x='8' y='58' width='20' height='5' $l/>"
           . "<rect x='32' y='58' width='20' height='5' $l/><rect x='8' y='67' width='104' height='4' $l/>"
           . "<rect x='8' y='74' width='104' height='4' $l/>",
    ];
    return "<svg viewBox='0 0 120 80' width='120' height='80' aria-hidden='true'>" . ($shapes[$id] ?? '') . '</svg>';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="robots" content="noindex">
  <title>Edit Site — Admin</title>
  <link rel="stylesheet" href="admin.css">
</head>
<body>
<?= admin_bar() ?>

<main class="admin-main">
  <?php if ($saved): ?><p class="alert success">Changes saved. Refresh the site to see them.</p><?php endif; ?>
  <?php if ($saved && !empty($_SESSION['embed_notice'])): foreach ($_SESSION['embed_notice'] as $n): ?><p class="alert success"><?= e($n) ?></p><?php endforeach; endif; unset($_SESSION['embed_notice']); ?>
  <?php if ($error): ?><p class="alert error"><?= e($error) ?></p><?php endif; ?>

  <nav class="jump" aria-label="Jump to section">
    <a href="#layout">Layout</a><a href="#details">Details</a><a href="#photos">Photos</a><a href="#gallery">Gallery</a>
    <a href="#colours">Colours</a><a href="#menu">Menu</a><a href="#hours">Hours</a><a href="#contact">Contact</a>
    <a href="#ordering">Ordering</a><a href="#seo">SEO</a><a href="#tracking">Tracking</a>
  </nav>

  <form method="post" enctype="multipart/form-data">
    <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">

    <section class="card" id="layout">
      <h2>Website layout</h2>
      <p class="hint">Choose how your website is arranged. Your text, photos and colours stay the same. Use Preview to see a layout before you save.</p>
      <div class="layout-picker">
        <?php foreach ($layouts as $id => $l): ?>
          <div class="layout-option">
            <label>
              <input type="radio" name="layout" value="<?= (int)$id ?>" <?= $id === $currentLayout ? 'checked' : '' ?>>
              <span class="layout-card">
                <?= layout_icon((int)$id) ?>
                <strong><?= e($l['name']) ?></strong>
                <small><?= e($l['description']) ?></small>
              </span>
            </label>
            <a href="../index.php?preview=<?= (int)$id ?>" target="_blank" class="preview-link">Preview <?= e($l['name']) ?></a>
          </div>
        <?php endforeach; ?>
      </div>
    </section>

    <section class="card" id="details">
      <h2>Business details</h2>
      <div class="field-row">
        <label>Cafe name <input name="name" value="<?= e($c['name']) ?>" required></label>
        <label>Tagline <input name="tagline" value="<?= e($c['tagline']) ?>"></label>
      </div>
      <label>About text <textarea name="about" rows="4"><?= e($c['about']) ?></textarea></label>
    </section>

    <section class="card" id="photos">
      <h2>Photos</h2>
      <p class="hint">JPG, PNG or WebP, under 5 MB each.</p>
      <div class="photo-row">
        <?= photo_tile('Hero image', 'The big banner photo', $c['images']['hero'] ?? '', 'hero_upload') ?>
        <?= photo_tile('Logo', 'Optional. Replaces the name in the header', $c['logo'] ?? '', 'logo_upload', 'remove_logo', 'logo') ?>
      </div>
    </section>

    <section class="card" id="gallery">
      <h2>Gallery photos</h2>
      <p class="hint">Square or landscape photos work best. Leave every slot empty to hide the gallery.</p>
      <?php $gal = array_values($c['images']['gallery'] ?? []); ?>
      <div class="photo-row photo-row-3">
        <?php for ($i = 0; $i < GALLERY_SLOTS; $i++): ?>
          <?= photo_tile('Photo ' . ($i + 1), '', (string)($gal[$i] ?? ''), "gallery_upload_$i", "remove_gallery_$i", 'square') ?>
        <?php endfor; ?>
      </div>
    </section>

    <section class="card" id="colours">
      <h2>Colours</h2>
      <p class="hint">Tap a swatch to change it.</p>
      <div class="colour-grid">
        <?php
        $colours = [
            'primary'    => ['Primary', 'Headings, footer and panels'],
            'accent'     => ['Accent', 'Buttons and highlights'],
            'background' => ['Page background', 'The main page colour'],
            'text'       => ['Body text', 'Paragraphs and menu items'],
            'surface'    => ['Cards and panels', 'Cards and alternate sections'],
        ];
        foreach ($colours as $key => [$cname, $cuse]):
            $val = $c['colors'][$key] ?? '#000000'; ?>
          <label class="colour">
            <input type="color" name="color_<?= $key ?>" value="<?= e($val) ?>">
            <span class="colour-text">
              <span class="colour-name"><?= e($cname) ?></span>
              <span class="colour-use"><?= e($cuse) ?></span>
            </span>
            <code class="colour-hex"><?= e(strtolower($val)) ?></code>
          </label>
        <?php endforeach; ?>
      </div>
    </section>

    <section class="card" id="menu">
      <h2>Menu</h2>
      <p class="hint">One item per line: <code>Category | Item | Price</code>. Leave empty to hide the menu.</p>
      <textarea name="menu" rows="12"><?= e(menu_to_text($c['menu'])) ?></textarea>
    </section>

    <section class="card" id="hours">
      <h2>Opening hours</h2>
      <p class="hint">One line per day: <code>Days | Hours</code>. Leave empty to hide the hours.</p>
      <textarea name="hours" rows="4"><?= e(pairs_to_text($c['hours'])) ?></textarea>
    </section>

    <section class="card" id="contact">
      <h2>Contact and social</h2>
      <p class="hint">Anything left empty is hidden on your website.</p>
      <label>Address <input name="address" value="<?= e($c['contact']['address']) ?>"></label>
      <div class="field-row">
        <label>Phone <input name="phone" value="<?= e($c['contact']['phone']) ?>"></label>
        <label>Email <input type="email" name="email" value="<?= e($c['contact']['email']) ?>"></label>
      </div>
      <label>Google Maps embed URL <input name="map_embed" value="<?= e($c['contact']['map_embed']) ?>"></label>
      <div class="field-row">
        <label>Instagram URL <input name="instagram" value="<?= e($c['social']['instagram']) ?>"></label>
        <label>Facebook URL <input name="facebook" value="<?= e($c['social']['facebook']) ?>"></label>
      </div>
    </section>

    <section class="card" id="ordering">
      <h2>Online ordering and booking</h2>
      <p class="hint">Paste the embed link from your ordering or booking provider. It must start with <code>https://</code>. If you were given embed code that starts with <code>&lt;iframe</code>, you can paste all of it. Leave a box empty to hide that section on your website. Some providers (Meandu, for example) do not allow their page inside other websites; the editor checks this when you save and shows a button that opens the provider instead.</p>
      <label>Online ordering embed URL
        <input type="text" inputmode="url" name="embed_ordering" placeholder="https://" autocomplete="off" value="<?= e($c['embeds']['ordering'] ?? '') ?>">
      </label>
      <label class="inline"><input type="checkbox" name="embed_ordering_button" value="1"<?= ($c['embeds']['ordering_mode'] ?? '') === 'button' ? ' checked' : '' ?>> Show as an "Order online" button that opens the provider, instead of inside the website</label>
      <label>Booking embed URL
        <input type="text" inputmode="url" name="embed_booking" placeholder="https://" autocomplete="off" value="<?= e($c['embeds']['booking'] ?? '') ?>">
      </label>
      <label class="inline"><input type="checkbox" name="embed_booking_button" value="1"<?= ($c['embeds']['booking_mode'] ?? '') === 'button' ? ' checked' : '' ?>> Show as a "Book a table" button that opens the provider, instead of inside the website</label>
      <div class="field-row">
        <label>Ordering button text <span class="hint">(blank = "Order online")</span>
          <input type="text" name="embed_ordering_label" maxlength="40" placeholder="Order online" value="<?= e($c['embeds']['ordering_label'] ?? '') ?>">
        </label>
        <label>Booking button text <span class="hint">(blank = "Book a table")</span>
          <input type="text" name="embed_booking_label" maxlength="40" placeholder="Book a table" value="<?= e($c['embeds']['booking_label'] ?? '') ?>">
        </label>
      </div>
      <?php
        $pvHex = function ($v, $d) { return preg_match('/^#[0-9a-f]{6}$/i', (string)$v) ? $v : $d; };
        $pvOn  = function ($hex) { $r = hexdec(substr($hex, 1, 2)); $g = hexdec(substr($hex, 3, 2)); $b = hexdec(substr($hex, 5, 2)); return (0.299 * $r + 0.587 * $g + 0.114 * $b) > 150 ? '#111' : '#fff'; };
        $pvP = $pvHex($c['colors']['primary'] ?? '', '#6F4E37'); $pvA = $pvHex($c['colors']['accent'] ?? '', '#D9A441');
        $curStyle = $c['embeds']['button_style'] ?? 'solid';
      ?>
      <p class="field-title">Button style <span class="hint">(used when a link is shown as a button)</span></p>
      <style><?= EMBED_BUTTON_CSS ?>
        .btn-styles{--primary:<?= e($pvP) ?>;--on-primary:<?= $pvOn($pvP) ?>;--accent:<?= e($pvA) ?>;--on-accent:<?= $pvOn($pvA) ?>;--text:<?= e($pvHex($c['colors']['text'] ?? '', '#2B2B2B')) ?>;--surface:<?= e($pvHex($c['colors']['surface'] ?? '', '#FFFFFF')) ?>;display:grid;grid-template-columns:repeat(auto-fill,minmax(230px,1fr));gap:.75rem;margin:.5rem 0 1rem}
        .btn-style{position:relative;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:.7rem;min-height:130px;padding:1.1rem .8rem .8rem;margin:0;border:2px solid var(--line);border-radius:12px;background:<?= e($pvHex($c['colors']['background'] ?? '', '#FBF7F2')) ?>;cursor:pointer;font-weight:400}
        .btn-style:hover{border-color:var(--brand)}
        .btn-style:has(input:checked){border-color:var(--brand);box-shadow:0 0 0 3px var(--brand-soft)}
        .btn-style input{position:absolute;top:.6rem;left:.6rem;width:auto;margin:0}
        .btn-style .embed-btn{pointer-events:none;font-size:1rem}
        .btn-style .embed-btn.s-card{min-width:0}
        .btn-style small{font-size:.8rem;color:#666}
      </style>
      <div class="btn-styles">
        <?php foreach (EMBED_BUTTON_STYLES as $sk => $sl): ?>
        <label class="btn-style">
          <input type="radio" name="embed_button_style" value="<?= e($sk) ?>"<?= $curStyle === $sk ? ' checked' : '' ?>>
          <span class="embed-btn s-<?= e($sk) ?>"><?php if ($sk === 'card'): ?><span class="t">Order online &rarr;</span><span class="sub">Opens in a new tab</span><?php else: ?>Order online &rarr;<?php endif; ?></span>
          <small><?= e($sl) ?></small>
        </label>
        <?php endforeach; ?>
      </div>
    </section>

    <section class="card" id="seo">
      <h2>Search and sharing (SEO)</h2>
      <p class="hint">Helps Google show your cafe properly and makes shared links look good. Your name, address, phone and opening hours are also passed to Google automatically.</p>
      <label>Website address <span class="hint">(needed for the sitemap, share pictures and Google listing data)</span>
        <input type="text" inputmode="url" name="seo_site_url" placeholder="https://www.yourcafe.com.au" value="<?= e($c['seo']['site_url'] ?? '') ?>">
      </label>
      <label>Page title <span class="hint">(optional, about 60 characters)</span>
        <input name="seo_title" maxlength="70" placeholder="<?= e($c['name'] . ' — ' . $c['tagline']) ?>" value="<?= e($c['seo']['title'] ?? '') ?>">
      </label>
      <label>Search result description <span class="hint">(optional, up to 160 characters)</span>
        <textarea name="seo_description" rows="2" maxlength="160" placeholder="Leave blank to use the start of your About text"><?= e($c['seo']['description'] ?? '') ?></textarea>
      </label>
      <label>Google Search Console code <span class="hint">(optional)</span>
        <input name="seo_search_console" placeholder="Paste the code, or the whole meta tag" value="<?= e($c['seo']['search_console'] ?? '') ?>">
      </label>
      <div class="photo-row">
        <?= photo_tile('Share picture', 'Shown in Facebook and WhatsApp links. Blank uses the hero photo', $c['seo']['share_image'] ?? '', 'share_upload', 'remove_share') ?>
        <?= photo_tile('Browser tab icon', 'Square PNG works best', $c['seo']['favicon'] ?? '', 'favicon_upload', 'remove_favicon', 'logo') ?>
      </div>
    </section>

    <section class="card" id="tracking">
      <h2>Tracking and ads</h2>
      <p class="hint">Paste just the ID from each service. Leave a box empty to switch it off. Taps on the Order online, Book a table and Call buttons are reported automatically. Previews from this dashboard are never counted.</p>
      <div class="field-row">
        <label>Google Analytics 4 ID
          <input name="trk_ga4" placeholder="G-ABC123XYZ4" autocomplete="off" value="<?= e($c['tracking']['ga4'] ?? '') ?>">
        </label>
        <label>Google Ads ID
          <input name="trk_gads" placeholder="AW-123456789" autocomplete="off" value="<?= e($c['tracking']['gads'] ?? '') ?>">
        </label>
      </div>
      <label>Google Ads conversion label <span class="hint">(optional, counts a conversion when someone taps Order, Book or Call)</span>
        <input name="trk_gads_label" autocomplete="off" value="<?= e($c['tracking']['gads_label'] ?? '') ?>">
      </label>
      <div class="field-row">
        <label>Google Tag Manager ID <span class="hint">(replaces the two Google IDs above)</span>
          <input name="trk_gtm" placeholder="GTM-ABC123" autocomplete="off" value="<?= e($c['tracking']['gtm'] ?? '') ?>">
        </label>
        <label>Meta (Facebook) Pixel ID
          <input name="trk_meta_pixel" placeholder="1234567890123456" autocomplete="off" value="<?= e($c['tracking']['meta_pixel'] ?? '') ?>">
        </label>
      </div>
      <label>Privacy policy link <span class="hint">(shown in the footer; Google requires one when you use analytics or ads)</span>
        <input name="trk_privacy_url" placeholder="https:// or /privacy.html" value="<?= e($c['tracking']['privacy_url'] ?? '') ?>">
      </label>
    </section>

    <div class="savebar">
      <button type="submit" class="btn-primary">Save changes</button>
    </div>
  </form>
</main>

<script>
// Show the colour code next to each swatch as it changes
document.querySelectorAll('.colour input[type=color]').forEach(function (input) {
  var out = input.closest('.colour').querySelector('.colour-hex');
  input.addEventListener('input', function () { out.textContent = input.value; });
});
</script>
</body>
</html>
