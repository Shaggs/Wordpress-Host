<?php
define('ROOT', dirname(__DIR__));
define('SESSION_TIMEOUT', 1800); // 30 minutes of inactivity
define('USERS_FILE', __DIR__ . '/users.php');
const ROLES = ['admin' => 'Admin', 'editor' => 'Editor'];

session_set_cookie_params([
    'lifetime' => 0,
    'path'     => '/',
    'secure'   => !empty($_SERVER['HTTPS']),
    'httponly' => true,
    'samesite' => 'Strict',
]);
session_start();

function e(string $s): string
{
    return htmlspecialchars($s, ENT_QUOTES, 'UTF-8');
}

/**
 * All admin accounts as  name => ['hash' => ..., 'role' => 'admin'|'editor', 'changed' => timestamp].
 * Older users.php formats still load: the single-user format and the  name => hash  list
 * (accounts from those formats are full admins, as they were before roles existed).
 */
function load_users(): array
{
    if (!is_file(USERS_FILE)) {
        return [];
    }
    if (function_exists('opcache_invalidate')) {
        @opcache_invalidate(USERS_FILE, true);
    }
    $raw = include USERS_FILE;
    if (!is_array($raw)) {
        return [];
    }
    if (isset($raw['username'], $raw['password_hash']) && is_string($raw['username'])) {
        $raw = [$raw['username'] => $raw['password_hash']];
    }
    $out = [];
    foreach ($raw as $name => $v) {
        if (!is_string($name) || $name === '') {
            continue;
        }
        if (is_string($v)) {
            $v = ['hash' => $v, 'role' => 'admin'];
        }
        if (!is_array($v) || !isset($v['hash']) || !is_string($v['hash'])) {
            continue;
        }
        $role = $v['role'] ?? 'editor';
        $out[$name] = [
            'hash'    => $v['hash'],
            'role'    => isset(ROLES[$role]) ? $role : 'editor',
            'changed' => (float)($v['changed'] ?? 0),
        ];
    }
    return $out;
}

function save_users(array $users): void
{
    ksort($users, SORT_FLAG_CASE | SORT_STRING);
    $php = "<?php\n// Admin accounts (managed from the site editor). Roles: admin, editor.\n"
         . 'return ' . var_export($users, true) . ";\n";
    $tmp = USERS_FILE . '.tmp';
    if (is_writable(__DIR__) && @file_put_contents($tmp, $php, LOCK_EX) !== false) {
        rename($tmp, USERS_FILE);
    } elseif (is_writable(USERS_FILE)) {
        if (@file_put_contents(USERS_FILE, $php, LOCK_EX) === false) {
            throw new RuntimeException('Could not save the user list. Check file permissions on admin/users.php.');
        }
    } else {
        throw new RuntimeException('Could not save the user list. Check file permissions on admin/users.php.');
    }
    if (function_exists('opcache_invalidate')) {
        @opcache_invalidate(USERS_FILE, true);
    }
}

function valid_username(string $name): bool
{
    return (bool)preg_match('/^[A-Za-z0-9._-]{3,40}$/', $name);
}

function password_problem(string $pw): ?string
{
    if (strlen($pw) < 8) {
        return 'Passwords must be at least 8 characters.';
    }
    if (strlen($pw) > 128) {
        return 'Passwords can be at most 128 characters.';
    }
    return null;
}

function admin_count(array $users): int
{
    return count(array_filter($users, fn($u) => $u['role'] === 'admin'));
}

function current_user(): string
{
    return (string)($_SESSION['admin_user'] ?? '');
}

function is_admin(): bool
{
    return ($_SESSION['admin_role'] ?? '') === 'admin';
}

function logout_to_login(): void
{
    $_SESSION = [];
    header('Location: login.php');
    exit;
}

function require_login(): void
{
    $expired = (time() - ($_SESSION['admin_last'] ?? 0)) > SESSION_TIMEOUT;
    if (empty($_SESSION['admin_ok']) || $expired || current_user() === '') {
        logout_to_login();
    }
    // Re-check the account on every page: a deleted account, or a password changed since this
    // sign-in (by the user elsewhere or by an admin), ends the session. Role changes apply at once.
    $users = load_users();
    $me = $users[current_user()] ?? null;
    if (!$me || $me['changed'] > (float)($_SESSION['admin_since'] ?? 0)) {
        logout_to_login();
    }
    $_SESSION['admin_role'] = $me['role'];
    $_SESSION['admin_last'] = time();
}

function require_admin(): void
{
    require_login();
    if (!is_admin()) {
        http_response_code(403);
        exit('Only admins can manage users. <a href="dashboard.php">Back to the editor</a>');
    }
}

/** Top bar shared by every admin page. */
function admin_bar(): string
{
    $o  = '<header class="admin-bar"><strong>Site Editor</strong><span>';
    $o .= '<span class="who">' . e(current_user()) . ' · ' . e(ROLES[$_SESSION['admin_role'] ?? 'editor'] ?? 'Editor') . '</span>';
    $o .= '<a href="dashboard.php">Edit site</a>';
    if (is_admin()) {
        $o .= '<a href="team.php">Users</a>';
    }
    $o .= '<a href="account.php">My password</a>';
    $o .= '<a href="../index.php" target="_blank">View site</a>';
    $o .= '<a href="logout.php">Log out</a>';
    return $o . '</span></header>';
}

function csrf_token(): string
{
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf'];
}

function check_csrf(): void
{
    $sent = $_POST['csrf'] ?? '';
    if (!hash_equals($_SESSION['csrf'] ?? '', $sent)) {
        http_response_code(403);
        exit('Your session form expired. Please go back, reload the page, and try again.');
    }
}
