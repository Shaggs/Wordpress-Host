<?php
require __DIR__ . '/auth.php';

if (!empty($_SESSION['admin_ok']) && current_user() !== '') {
    header('Location: dashboard.php');
    exit;
}

$users = load_users();
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    check_csrf();

    if (!empty($_SESSION['locked_until']) && time() < $_SESSION['locked_until']) {
        $error = 'Too many failed attempts. Please wait 15 minutes and try again.';
    } else {
        $user = trim($_POST['username'] ?? '');
        $pass = $_POST['password'] ?? '';

        // Always run password_verify so response time doesn't reveal which usernames exist
        $hash = $users[$user]['hash'] ?? password_hash('not-a-real-user', PASSWORD_DEFAULT);
        $ok   = isset($users[$user]) && password_verify($pass, $hash);

        if ($ok) {
            session_regenerate_id(true);
            $_SESSION['admin_ok']       = true;
            $_SESSION['admin_user']     = $user;
            $_SESSION['admin_role']     = $users[$user]['role'];
            $_SESSION['admin_since']    = microtime(true);
            $_SESSION['admin_last']     = time();
            $_SESSION['login_failures'] = 0;
            unset($_SESSION['locked_until']);
            header('Location: dashboard.php');
            exit;
        }

        $_SESSION['login_failures'] = ($_SESSION['login_failures'] ?? 0) + 1;
        if ($_SESSION['login_failures'] >= 5) {
            $_SESSION['locked_until']   = time() + 900;
            $_SESSION['login_failures'] = 0;
        }
        usleep(500000);
        $error = 'Incorrect username or password.';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="robots" content="noindex">
  <title>Admin Login</title>
  <link rel="stylesheet" href="admin.css">
</head>
<body class="login-body">
  <form method="post" class="login-card">
    <h1>Site Admin</h1>
    <?php if ($error): ?><p class="alert error"><?= e($error) ?></p><?php endif; ?>

    <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">

    <label>Username
      <input type="text" name="username" required autofocus autocomplete="username">
    </label>
    <label>Password
      <input type="password" name="password" required autocomplete="current-password">
    </label>

    <button type="submit" class="btn-primary">Log in</button>
  </form>
</body>
</html>
