<?php
// Served as /sitemap.xml (see .htaccess)
$c   = require __DIR__ . '/config.php';
$url = rtrim((string)($c['seo']['site_url'] ?? ''), '/');
if ($url === '') {
    http_response_code(404);
    exit('Set the website address in the admin dashboard to enable the sitemap.');
}
header('Content-Type: application/xml; charset=utf-8');
echo '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
  <url>
    <loc><?= htmlspecialchars($url . '/', ENT_XML1, 'UTF-8') ?></loc>
    <lastmod><?= date('Y-m-d', filemtime(__DIR__ . '/config.php')) ?></lastmod>
  </url>
</urlset>
