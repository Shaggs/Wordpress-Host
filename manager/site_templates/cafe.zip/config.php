<?php
// ============================================================
// CUSTOMER CONFIG (managed by the admin dashboard)
// ============================================================
return [
    'name'    => 'The Daily Grind',
    'tagline' => 'Locally roasted coffee & fresh bakes',
    'logo'    => null,

    // Which website layout to show: 1 = Classic, 2 = Split screen, 3 = Menu first
    'layout'  => 1,

    'colors' => [
        'primary'    => '#6F4E37',
        'accent'     => '#D9A441',
        'background' => '#FBF7F2',
        'text'       => '#2B2B2B',
        'surface'    => '#FFFFFF',
    ],

    'images' => [
        'hero'    => 'assets/images/hero.jpg',
        'gallery' => [
            'assets/images/gallery1.jpg',
            'assets/images/gallery2.jpg',
            'assets/images/gallery3.jpg',
        ],
    ],

    'about' => "A family-run cafe serving great coffee since 2015. We source our beans from small roasters and bake everything in-house every morning.",

    'menu' => [
        'Coffee' => [
            ['item' => 'Flat White',   'price' => '$5.00'],
            ['item' => 'Long Black',   'price' => '$4.50'],
            ['item' => 'Cold Brew',    'price' => '$6.00'],
        ],
        'Food' => [
            ['item' => 'Avocado Toast',       'price' => '$16.00'],
            ['item' => 'Banana Bread',        'price' => '$5.50'],
            ['item' => 'Breakfast Burrito',   'price' => '$14.00'],
        ],
    ],

    'hours' => [
        'Mon–Fri' => '7:00am – 4:00pm',
        'Sat–Sun' => '8:00am – 3:00pm',
    ],

    'contact' => [
        'address'   => '12 Example Street, Suburb NSW 2000',
        'phone'     => '(02) 0000 0000',
        'email'     => 'hello@example.com',
        'map_embed' => '',
    ],

    // Embedded pages from your ordering / booking provider (https:// links). Blank = hidden.
    'embeds' => [
        'ordering' => '',
        'booking'  => '',
    ],

    // Search engines and link previews. Leave blank to use the defaults.
    'seo' => [
        'title'          => '',     // blank = "Name — Tagline"
        'description'    => '',     // blank = start of the About text
        'site_url'       => '',     // e.g. https://www.yourcafe.com.au
        'search_console' => '',     // Google Search Console verification code
        'share_image'    => null,   // picture shown when the link is shared
        'favicon'        => null,
    ],

    // Analytics and advertising IDs (blank = off)
    'tracking' => [
        'ga4'         => '',        // G-XXXXXXXXXX
        'gads'        => '',        // AW-XXXXXXXXX
        'gads_label'  => '',        // conversion label for Order / Book / Call taps
        'gtm'         => '',        // GTM-XXXXXXX (replaces the two above)
        'meta_pixel'  => '',
        'privacy_url' => '',        // shown as a footer link
    ],

    'social' => [
        'instagram' => 'https://instagram.com/',
        'facebook'  => 'https://facebook.com/',
    ],
];
